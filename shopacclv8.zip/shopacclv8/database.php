<?php
// Database connection and helper functions

/**
 * Get PDO database connection
 */
function getDbConnection() {
    global $db_host, $db_name, $db_user, $db_pass;
    
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            
            $pdo = new PDO($dsn, $db_user, $db_pass, $options);
            
        } catch (PDOException $e) {
            if (isset($debug) && $debug) {
                echo "Connection failed: " . $e->getMessage();
            }
            die("Database connection error. Please try again later.");
        }
    }
    
    return $pdo;
}

/**
 * Execute a query and return a single record
 */
function find($query, $params = []) {
    try {
        $stmt = getDbConnection()->prepare($query);
        $stmt->execute($params);
        return $stmt->fetch();
    } catch (PDOException $e) {
        if (isset($debug) && $debug) {
            echo "Query error: " . $e->getMessage();
        }
        return false;
    }
}

/**
 * Execute a query and return all records
 */
function findAll($query, $params = []) {
    try {
        $stmt = getDbConnection()->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        if (isset($debug) && $debug) {
            echo "Query error: " . $e->getMessage();
        }
        return [];
    }
}

/**
 * Insert a record into a table
 */
function insert($table, $data) {
    $keys = array_keys($data);
    $fields = '`' . implode('`, `', $keys) . '`';
    $placeholders = ':' . implode(', :', $keys);
    
    $query = "INSERT INTO {$table} ({$fields}) VALUES ({$placeholders})";
    
    try {
        $stmt = getDbConnection()->prepare($query);
        $stmt->execute($data);
        return getDbConnection()->lastInsertId();
    } catch (PDOException $e) {
        if (isset($debug) && $debug) {
            echo "Insert error: " . $e->getMessage();
        }
        return false;
    }
}

/**
 * Update records in a table
 */
function update($table, $data, $where, $whereParams = []) {
    $sets = [];
    foreach (array_keys($data) as $key) {
        $sets[] = "`{$key}` = :{$key}";
    }
    
    $query = "UPDATE {$table} SET " . implode(', ', $sets) . " WHERE {$where}";
    
    try {
        $stmt = getDbConnection()->prepare($query);
        $stmt->execute(array_merge($data, $whereParams));
        return $stmt->rowCount();
    } catch (PDOException $e) {
        if (isset($debug) && $debug) {
            echo "Update error: " . $e->getMessage();
        }
        return false;
    }
}

/**
 * Delete records from a table
 */
function delete($table, $where, $params = []) {
    $query = "DELETE FROM {$table} WHERE {$where}";
    
    try {
        $stmt = getDbConnection()->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        if (isset($debug) && $debug) {
            echo "Delete error: " . $e->getMessage();
        }
        return false;
    }
}

/**
 * Get a setting value from the database
 */
function getSetting($key, $default = null) {
    $setting = find("SELECT value FROM settings WHERE `key` = :key", ['key' => $key]);
    
    if ($setting) {
        return $setting['value'];
    }
    
    return $default;
}

function generateRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
?> 