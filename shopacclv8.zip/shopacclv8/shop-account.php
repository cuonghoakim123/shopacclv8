<?php
// Include configuration and database connection
require_once 'config.php';

// Start session is handled in config.php

// Get user balance and discount (if logged in)
$user_balance = isset($_SESSION['user_balance']) ? $_SESSION['user_balance'] : 1000000; // Default value
$discount = isset($_SESSION['discount_percent']) ? $_SESSION['discount_percent'] : 10; // Default discount

// Handle search and category filtering
$search = isset($_GET['search']) ? validateInput($_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// Build the query
$sql = "SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE 1=1";

if ($search) {
    $sql .= " AND (p.name LIKE :search OR c.name LIKE :search)";
}

if ($category) {
    $sql .= " AND p.category_id = :category";
}

$sql .= " ORDER BY p.id DESC";

// Execute the query
try {
    $stmt = getDbConnection()->prepare($sql);
    
    if ($search) {
        $searchParam = "%{$search}%";
        $stmt->bindParam(':search', $searchParam);
    }
    
    if ($category) {
        $stmt->bindParam(':category', $category);
    }
    
    $stmt->execute();
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    // Handle error
    $products = [];
    if ($debug) {
        echo "Query error: " . $e->getMessage();
    }
}

// Get all categories for the filter
$categories = findAll("SELECT * FROM categories WHERE status = 1 ORDER BY id ASC");
?>

<!doctype html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mua Tài Khoản - Shop Accl V8</title>
  <link rel="shortcut icon" href="assets/storage/images/favicon_UPQ.png" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
  <!-- Bootstrap 4.6 & Font Awesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" 
        integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" 
        crossorigin="anonymous" referrerpolicy="no-referrer" />
  <style>
    /* Variables & Global Settings */
    :root {
      --primary-color: #013B7B;
      --secondary-color: #12214E;
      --accent-color: #FF9900;
      --light-bg: #f4f6fc;
      --font-family: 'Poppins', sans-serif;
      --shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    }
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: var(--font-family);
      background: var(--light-bg);
      color: #333;
      overflow-x: hidden;
      line-height: 1.6;
    }
    a {
      text-decoration: none;
      transition: all 0.3s ease;
    }
    a:hover {
      color: var(--accent-color);
    }

    /* Layout */
    .wrapper {
      display: flex;
      min-height: 100vh;
      transition: all 0.3s ease;
    }

    /* Sidebar */
    .iq-sidebar {
      width: 260px;
      background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
      padding: 20px;
      position: fixed;
      height: 100vh;
      box-shadow: var(--shadow);
      z-index: 100;
      transition: transform 0.3s ease;
    }
    .iq-sidebar-logo {
      text-align: center;
      margin-bottom: 40px;
    }
    .iq-sidebar-logo img {
      max-width: 80%;
      border-radius: 15px;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
    }
    .iq-sidebar-logo img:hover {
      transform: scale(1.1);
      box-shadow: 0 5px 15px rgba(255, 153, 0, 0.5);
    }
    .iq-sidebar-menu {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .iq-sidebar-menu li {
      margin-bottom: 12px;
      position: relative;
    }
    .iq-sidebar-menu li a, 
    .iq-sidebar-menu li span {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      border-radius: 10px;
      font-weight: 500;
      color: #fff;
      transition: all 0.3s ease;
    }
    .iq-sidebar-menu li a:hover,
    .iq-sidebar-menu li a.active {
      background: var(--accent-color);
      transform: translateX(10px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    .iq-sidebar-menu li a i {
      margin-right: 10px;
      transition: transform 0.3s ease;
    }
    .iq-sidebar-menu li a:hover i {
      transform: scale(1.2);
    }

    /* Main Content */
    .content-page {
      flex: 1;
      margin-left: 260px;
      padding: 50px 40px;
      background: linear-gradient(135deg, #ffffff 0%, #e9eff5 100%);
      position: relative;
      overflow: hidden;
    }
    .content-page::before {
      content: "";
      position: absolute;
      top: -50px;
      left: -50px;
      width: 120%;
      height: 300px;
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      z-index: -1;
      border-bottom-left-radius: 60% 40%;
      border-bottom-right-radius: 60% 40%;
      opacity: 0.4;
      transform: rotate(-5deg);
    }

    /* Search & Category */
    .search-wrapper {
      margin-bottom: 40px;
    }
    .search-input {
      border-radius: 50px;
      padding: 12px 20px;
      border: none;
      box-shadow: var(--shadow);
      transition: all 0.3s ease;
    }
    .search-input:focus {
      box-shadow: 0 5px 20px rgba(255, 153, 0, 0.3);
      border-color: var(--accent-color);
    }
    .btn-outline-secondary,
    .btn-primary {
      border-radius: 50px;
      padding: 10px 25px;
      transition: all 0.3s ease;
    }
    .btn-outline-secondary:hover,
    .btn-primary:hover {
      background: var(--accent-color);
      color: #fff;
      box-shadow: 0 5px 15px rgba(255, 153, 0, 0.4);
      transform: translateY(-2px);
    }

    .categories-wrapper {
      text-align: center;
      margin-bottom: 40px;
    }
    .category-pill {
      display: inline-block;
      padding: 12px 25px;
      margin: 8px;
      border-radius: 50px;
      background: rgba(18, 33, 78, 0.8);
      color: #fff;
      font-size: 15px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    .category-pill:hover,
    .category-pill.active {
      background: var(--accent-color);
      transform: scale(1.1);
      box-shadow: 0 5px 15px rgba(255, 153, 0, 0.4);
    }

    /* Cards */
    .card-product {
      background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
      color: #fff;
      border-radius: 20px;
      overflow: hidden;
      position: relative;
      transition: all 0.4s ease;
      box-shadow: var(--shadow);
    }
    .card-product:hover {
      transform: scale(1.05);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
    }
    .card-product .card-body {
      padding: 25px;
    }
    .card-product h5 {
      font-size: 1.3rem;
      font-weight: 600;
      margin-bottom: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .card-product p {
      margin-bottom: 8px;
      opacity: 0.9;
    }
    .card-product .stock-badge {
      position: absolute;
      top: 15px;
      right: 15px;
      background: var(--accent-color);
      color: #fff;
      padding: 6px 15px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 600;
      box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
    }
    .card-product:hover .stock-badge {
      transform: rotate(10deg);
    }

    /* Button */
    .btn-primary {
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      border: none;
      font-weight: 600;
      padding: 12px 30px;
    }
    .btn-primary:hover {
      background: var(--accent-color);
    }
    .btn-secondary:disabled {
      background: #ccc;
      border: none;
      cursor: not-allowed;
      opacity: 0.7;
    }

    /* Responsive Adjustments */
    @media (max-width: 991px) {
      .iq-sidebar {
        width: 100%;
        height: auto;
        position: relative;
        padding: 15px;
      }
      .content-page {
        margin-left: 0;
        padding: 30px 20px;
      }
      .card-product {
        margin: 0 auto;
        max-width: 350px;
      }
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <!-- Sidebar -->
    <aside class="iq-sidebar">
      <div class="iq-sidebar-logo">
        <a href="home.php">
          <img src="assets/storage/images/5.jpg" alt="Shop Accl V8 Logo">
        </a>
      </div>
      <ul class="iq-sidebar-menu">
        <li class="px-3 pb-2">
          <span>Số Dư: <strong style="color: var(--accent-color);"><?php echo number_format($user_balance, 0, ',', '.'); ?> VNĐ</strong> - Giảm: <strong style="color: red;"><?php echo $discount; ?>%</strong></span>
        </li>
        <li>
          <a href="home.php"><i class="fas fa-home"></i> <span class="ml-2">Bảng Điều Khiển</span></a>
        </li>
        <li>
          <a href="shop-account.php" class="active"><i class="fas fa-shopping-cart"></i> <span class="ml-2">Mua Tài Khoản</span></a>
        </li>
        <li>
          <a href="orders.php"><i class="fas fa-history"></i> <span class="ml-2">Lịch Sử Mua Hàng</span></a>
        </li>
        <li>
          <a href="top-money.php"><i class="fas fa-trophy"></i> <span class="ml-2">Bảng Xếp Hạng</span></a>
        </li>
        <li class="px-3 pt-3 pb-2">
          <span>Nạp Tiền</span>
        </li>
        <li>
          <a href="recharge.php"><i class="fas fa-university"></i> <span class="ml-2">Ngân Hàng</span></a>
        </li>
        <li>
          <a href="invoices.php"><i class="fas fa-file-invoice"></i> <span class="ml-2">Hoá Đơn</span></a>
        </li>
        <li>
          <a href="nap-the.php"><i class="fas fa-credit-card"></i> <span class="ml-2">Nạp Thẻ</span></a>
        </li>
        <li class="px-3 pt-3 pb-2">
          <span>Tài Khoản</span>
        </li>
        <li>
          <a href="profile.php"><i class="fas fa-user-edit"></i> <span class="ml-2">Thông Tin Tài Khoản</span></a>
        </li>
        <li>
          <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="ml-2">Đăng Xuất</span></a>
        </li>
      </ul>
    </aside>
    <!-- Main Content -->
    <main class="content-page">
      <div class="container-fluid">
        <!-- Search & Refresh -->
        <div class="row mb-4 align-items-center">
          <div class="col-md-6">
            <form action="shop-account.php" method="GET">
              <div class="input-group">
                <input type="text" class="form-control search-input" name="search" placeholder="Tìm kiếm sản phẩm..." value="<?php echo htmlspecialchars($search); ?>">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> Tìm kiếm</button>
                </div>
              </div>
            </form>
          </div>
          <div class="col-md-6 text-right">
            <a href="shop-account.php" class="btn btn-outline-secondary"><i class="fas fa-sync-alt"></i> Làm mới</a>
          </div>
        </div>
        <!-- Categories -->
        <div class="categories-wrapper text-center mb-4">
          <a href="shop-account.php" class="category-pill <?php echo (!$category && !$search) ? 'active' : ''; ?>">Tất cả</a>
          <?php foreach ($categories as $cat): ?>
          <a href="shop-account.php?category=<?php echo $cat['id']; ?>" class="category-pill <?php echo $category == $cat['id'] ? 'active' : ''; ?>"><?php echo htmlspecialchars($cat['name']); ?></a>
          <?php endforeach; ?>
        </div>
        <!-- Product List -->
        <div class="row">
          <?php if (empty($products)): ?>
            <div class="col-12 text-center">
              <p>Không tìm thấy sản phẩm nào.</p>
            </div>
          <?php else: ?>
            <?php foreach ($products as $product): ?>
              <div class="col-md-4 mb-4">
                <div class="card card-product">
                  <div class="card-body">
                    <div class="stock-badge">Còn: <?php echo $product['stock']; ?></div>
                    <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                    <p class="small"><?php echo htmlspecialchars($product['category_name']); ?></p>
                    <p class="card-text font-weight-bold">Giá: <?php echo number_format($product['price'], 0, ',', '.'); ?> VNĐ</p>
                    <p class="small">Đã bán: <?php echo $product['sold']; ?></p>
                    <?php if ($product['stock'] > 0): ?>
                      <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-primary btn-block">Mua Ngay</a>
                    <?php else: ?>
                      <button class="btn btn-secondary btn-block" disabled>Hết hàng</button>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function(){
      // Hiệu ứng fade-in khi tải trang
      $('.card-product').each(function(i) {
        $(this).delay(i * 200).fadeIn(500);
      });
    });
  </script>
</body>
</html>