<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Lấy thông tin người dùng từ database
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Lấy danh sách hoá đơn nạp tiền của người dùng
$invoices = findAll("SELECT * FROM deposits 
                     WHERE user_id = :user_id 
                     ORDER BY created_at DESC", 
                     ['user_id' => $user_id]);

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.png');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Hoá Đơn Nạp Tiền - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/responsive.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Roboto', sans-serif;    
    }

    .iq-sidebar {
        background: linear-gradient(#12214E, #12214E, #013B7B);
    }

    .change-mode .custom-switch.custom-switch-icon label.custom-control-label:after {
        top: 0;
        left: 0;
        width: 35px;
        height: 30px;
        border-radius: 5px 0 0 5px;
        background-color: #12214E;
        border-color: #12214E;
        z-index: 0;
    }
    </style>
</head>
<body class="color-light">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="iq-sidebar sidebar-default">
            <div class="iq-sidebar-logo d-flex align-items-end justify-content-between">
                <a href="<?php echo $base_url; ?>/home.php" class="header-logo">
                    <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="img-fluid rounded-normal light-logo" alt="logo">
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <li class="px-3 pt-3 pb-2">
                            <span class="text-uppercase small font-weight-bold">Số Dư <span style="color: yellow;"><?php echo formatMoney($balance); ?></span> - Giảm: <span style="color: red;"><?php echo $discount; ?>%</span>
                            </span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php" class="svg-icon">
                                <i class="fas fa-home"></i>
                                <span class="ml-2">Bảng Điều Khiển</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/shop-account.php" class="svg-icon">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="ml-2">Mua Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/orders.php" class="svg-icon">
                                <i class="fas fa-history"></i>
                                <span class="ml-2">Lịch Sử Mua Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/top-money.php" class="svg-icon">
                                <i class="fas fa-trophy"></i>
                                <span class="ml-2">Bảng Xếp Hạng</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Nạp Tiền</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/recharge.php" class="svg-icon">
                                <i class="fas fa-university"></i>
                                <span class="ml-2">Ngân Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/invoices.php" class="svg-icon active">
                                <i class="fas fa-file-invoice"></i>
                                <span class="ml-2">Hoá Đơn</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/nap-the.php" class="svg-icon">
                                <i class="fas fa-credit-card"></i>
                                <span class="ml-2">Nạp Thẻ</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Tài Khoản</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/profile.php" class="svg-icon">
                                <i class="fas fa-user-edit"></i>
                                <span class="ml-2">Thông Tin Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php?logout=1" class="svg-icon">
                                <i class="fas fa-sign-out-alt"></i>
                                <span class="ml-2">Đăng Xuất</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Hoá Đơn Nạp Tiền</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if(count($invoices) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Mã giao dịch</th>
                                                <th>Phương thức</th>
                                                <th>Số tiền</th>
                                                <th>Thời gian</th>
                                                <th>Cập nhật</th>
                                                <th>Trạng thái</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($invoices as $invoice): ?>
                                            <tr>
                                                <td><?php echo $invoice['transaction_code']; ?></td>
                                                <td><?php echo htmlspecialchars($invoice['payment_method']); ?></td>
                                                <td><?php echo formatMoney($invoice['amount']); ?></td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($invoice['created_at'])); ?></td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($invoice['updated_at'])); ?></td>
                                                <td>
                                                    <?php if($invoice['status'] == 0): ?>
                                                    <span class="badge badge-warning">Đang xử lý</span>
                                                    <?php elseif($invoice['status'] == 1): ?>
                                                    <span class="badge badge-success">Thành công</span>
                                                    <?php else: ?>
                                                    <span class="badge badge-danger">Đã hủy</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php else: ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle"></i> Bạn chưa có hoá đơn nạp tiền nào.
                                </div>
                                <a href="<?php echo $base_url; ?>/recharge.php" class="btn btn-primary">
                                    <i class="fas fa-university"></i> Nạp tiền ngay
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo $base_url; ?>/public/js/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });
        });
    </script>
</body>
</html> 