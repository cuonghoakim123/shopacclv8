<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Xử lý đăng xuất
if (isset($_GET['logout'])) {
    session_destroy();
    redirect($base_url . '/login.php');
}

// Lấy thông tin người dùng từ database
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

// Kiểm tra xem có phải là admin không (ID = 1 là admin)
if ($user['id'] != 1) {
    redirect($base_url . '/home.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/logo_dark_XGI.png');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');

// Xử lý upload logo
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nếu người dùng chọn logo để upload
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['logo']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        // Kiểm tra định dạng file
        if (in_array(strtolower($filetype), $allowed)) {
            // Tạo tên file ngẫu nhiên để tránh trùng lặp
            $newfilename = 'logo_' . uniqid() . '.' . $filetype;
            $uploadPath = 'assets/storage/images/' . $newfilename;
            
            // Upload file
            if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadPath)) {
                // Cập nhật đường dẫn trong database
                try {
                    $stmt = $conn->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = 'site_logo'");
                    $stmt->execute(['value' => $uploadPath]);
                    $site_logo = $uploadPath; // Cập nhật lại biến để hiển thị ngay
                    $message = 'Logo đã được cập nhật thành công!';
                    $messageType = 'success';
                } catch (Exception $e) {
                    $message = 'Có lỗi xảy ra khi cập nhật database: ' . $e->getMessage();
                    $messageType = 'danger';
                }
            } else {
                $message = 'Có lỗi xảy ra khi upload file!';
                $messageType = 'danger';
            }
        } else {
            $message = 'Chỉ chấp nhận file JPG, JPEG, PNG và GIF!';
            $messageType = 'danger';
        }
    }
    
    // Nếu người dùng chọn favicon để upload
    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'ico', 'gif'];
        $filename = $_FILES['favicon']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        // Kiểm tra định dạng file
        if (in_array(strtolower($filetype), $allowed)) {
            // Tạo tên file ngẫu nhiên để tránh trùng lặp
            $newfilename = 'favicon_' . uniqid() . '.' . $filetype;
            $uploadPath = 'assets/storage/images/' . $newfilename;
            
            // Upload file
            if (move_uploaded_file($_FILES['favicon']['tmp_name'], $uploadPath)) {
                // Cập nhật đường dẫn trong database
                try {
                    $stmt = $conn->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = 'site_favicon'");
                    $stmt->execute(['value' => $uploadPath]);
                    $site_favicon = $uploadPath; // Cập nhật lại biến để hiển thị ngay
                    $message = 'Favicon đã được cập nhật thành công!';
                    $messageType = 'success';
                } catch (Exception $e) {
                    $message = 'Có lỗi xảy ra khi cập nhật database: ' . $e->getMessage();
                    $messageType = 'danger';
                }
            } else {
                $message = 'Có lỗi xảy ra khi upload file!';
                $messageType = 'danger';
            }
        } else {
            $message = 'Chỉ chấp nhận file JPG, JPEG, PNG, ICO và GIF!';
            $messageType = 'danger';
        }
    }
    
    // Nếu người dùng chọn sử dụng logo có sẵn
    if (isset($_POST['preset_logo']) && !empty($_POST['preset_logo'])) {
        $preset_logo = validateInput($_POST['preset_logo']);
        
        // Kiểm tra xem file có tồn tại không
        if (file_exists($preset_logo)) {
            try {
                $stmt = $conn->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = 'site_logo'");
                $stmt->execute(['value' => $preset_logo]);
                $site_logo = $preset_logo; // Cập nhật lại biến để hiển thị ngay
                $message = 'Logo đã được cập nhật thành công!';
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Có lỗi xảy ra khi cập nhật database: ' . $e->getMessage();
                $messageType = 'danger';
            }
        } else {
            $message = 'File không tồn tại!';
            $messageType = 'danger';
        }
    }
    
    // Nếu người dùng chọn sử dụng favicon có sẵn
    if (isset($_POST['preset_favicon']) && !empty($_POST['preset_favicon'])) {
        $preset_favicon = validateInput($_POST['preset_favicon']);
        
        // Kiểm tra xem file có tồn tại không
        if (file_exists($preset_favicon)) {
            try {
                $stmt = $conn->prepare("UPDATE settings SET setting_value = :value WHERE setting_key = 'site_favicon'");
                $stmt->execute(['value' => $preset_favicon]);
                $site_favicon = $preset_favicon; // Cập nhật lại biến để hiển thị ngay
                $message = 'Favicon đã được cập nhật thành công!';
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Có lỗi xảy ra khi cập nhật database: ' . $e->getMessage();
                $messageType = 'danger';
            }
        } else {
            $message = 'File không tồn tại!';
            $messageType = 'danger';
        }
    }
}

// Lấy danh sách hình ảnh có sẵn
$imageDir = 'assets/storage/images/';
$images = [];

if (is_dir($imageDir)) {
    $files = scandir($imageDir);
    foreach ($files as $file) {
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        if (in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif', 'ico'])) {
            $images[] = $imageDir . $file;
        }
    }
}

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Quản lý Logo - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/responsive.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/modernize.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Roboto', sans-serif;    
    }

    .card-product {
        color: white;
        background-image: linear-gradient(to right, #12214E, #12214E, #013B7B);
    }

    .iq-sidebar {
        background: linear-gradient(#12214E, #12214E, #013B7B);
    }

    .change-mode .custom-switch.custom-switch-icon label.custom-control-label:after {
        top: 0;
        left: 0;
        width: 35px;
        height: 30px;
        border-radius: 5px 0 0 5px;
        background-color: #12214E;
        border-color: #12214E;
        z-index: 0;
    }
    
    .preset-image {
        width: 100px;
        height: 100px;
        object-fit: contain;
        margin: 5px;
        cursor: pointer;
        border: 2px solid transparent;
    }
    
    .preset-image.selected {
        border: 2px solid #007bff;
    }
    
    #previewLogo, #previewFavicon {
        max-width: 200px;
        max-height: 200px;
        object-fit: contain;
    }
    </style>
</head>
<body class="color-light">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="iq-sidebar sidebar-default">
            <div class="iq-sidebar-logo d-flex align-items-end justify-content-between">
                <a href="<?php echo $base_url; ?>/home.php" class="header-logo">
                    <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="img-fluid rounded-normal light-logo" alt="logo">
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>

            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <li class="px-3 pt-3 pb-2">
                            <span class="text-uppercase small font-weight-bold">Số Dư <span style="color: yellow;"><?php echo formatMoney($balance); ?></span> - Giảm: <span style="color: red;"><?php echo $discount; ?>%</span>
                            </span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php" class="svg-icon">
                                <i class="fas fa-home"></i>
                                <span class="ml-2">Bảng Điều Khiển</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/admin_logo.php" class="svg-icon active">
                                <i class="fas fa-image"></i>
                                <span class="ml-2">Quản lý Logo</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="#" id="dark-mode-toggle" class="svg-icon">
                                <i class="fas fa-moon"></i>
                                <span class="ml-2">Chế độ tối</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php?logout=1" class="svg-icon">
                                <i class="fas fa-sign-out-alt"></i>
                                <span class="ml-2">Đăng Xuất</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Quản lý Logo và Favicon</h4>
                                </div>
                                <div class="card-header-toolbar">
                                    <a href="<?php echo $base_url; ?>/home.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Về Trang Chủ</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($message)): ?>
                                <div class="alert alert-<?php echo $messageType; ?>">
                                    <?php echo $message; ?>
                                </div>
                                <?php endif; ?>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-header">
                                                <h5 class="card-title">Logo Hiện Tại</h5>
                                            </div>
                                            <div class="card-body text-center">
                                                <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="mb-3" id="previewLogo" alt="Current Logo">
                                                <p>Đường dẫn: <?php echo $site_logo; ?></p>
                                            </div>
                                        </div>
                                        
                                        <div class="card mt-3">
                                            <div class="card-header">
                                                <h5 class="card-title">Upload Logo Mới</h5>
                                            </div>
                                            <div class="card-body">
                                                <form method="POST" enctype="multipart/form-data">
                                                    <div class="form-group">
                                                        <label for="logo">Chọn file logo (JPG, JPEG, PNG, GIF)</label>
                                                        <input type="file" class="form-control-file" id="logo" name="logo" accept=".jpg,.jpeg,.png,.gif">
                                                    </div>
                                                    <button type="submit" class="btn btn-primary">Upload Logo</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-header">
                                                <h5 class="card-title">Favicon Hiện Tại</h5>
                                            </div>
                                            <div class="card-body text-center">
                                                <img src="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" class="mb-3" id="previewFavicon" alt="Current Favicon">
                                                <p>Đường dẫn: <?php echo $site_favicon; ?></p>
                                            </div>
                                        </div>
                                        
                                        <div class="card mt-3">
                                            <div class="card-header">
                                                <h5 class="card-title">Upload Favicon Mới</h5>
                                            </div>
                                            <div class="card-body">
                                                <form method="POST" enctype="multipart/form-data">
                                                    <div class="form-group">
                                                        <label for="favicon">Chọn file favicon (JPG, JPEG, PNG, ICO, GIF)</label>
                                                        <input type="file" class="form-control-file" id="favicon" name="favicon" accept=".jpg,.jpeg,.png,.ico,.gif">
                                                    </div>
                                                    <button type="submit" class="btn btn-primary">Upload Favicon</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="card mt-4">
                                    <div class="card-header">
                                        <h5 class="card-title">Hình ảnh có sẵn</h5>
                                    </div>
                                    <div class="card-body">
                                        <p>Chọn một trong những hình ảnh có sẵn để sử dụng làm logo hoặc favicon:</p>
                                        
                                        <div class="row">
                                            <?php foreach ($images as $image): ?>
                                            <div class="col-md-2 col-sm-4 col-6 mb-3">
                                                <div class="card">
                                                    <img src="<?php echo $base_url; ?>/<?php echo $image; ?>" class="card-img-top preset-image" alt="Preset Image">
                                                    <div class="card-body p-2 text-center">
                                                        <form method="POST">
                                                            <input type="hidden" name="preset_logo" value="<?php echo $image; ?>">
                                                            <button type="submit" class="btn btn-sm btn-outline-primary">Dùng làm Logo</button>
                                                        </form>
                                                        <form method="POST" class="mt-1">
                                                            <input type="hidden" name="preset_favicon" value="<?php echo $image; ?>">
                                                            <button type="submit" class="btn btn-sm btn-outline-secondary">Dùng làm Favicon</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo $base_url; ?>/public/js/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });
            
            // Preview uploaded logo
            $('#logo').change(function() {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#previewLogo').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
            
            // Preview uploaded favicon
            $('#favicon').change(function() {
                var file = this.files[0];
                if (file) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#previewFavicon').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>

    <!-- Core scripts -->
    <script src="<?php echo $base_url; ?>/public/datum/assets/js/backend-bundle.min.js"></script>
    <script src="<?php echo $base_url; ?>/public/datum/assets/js/app.js"></script>
    <script src="<?php echo $base_url; ?>/resources/js/modernize.js"></script>
</body>
</html> 