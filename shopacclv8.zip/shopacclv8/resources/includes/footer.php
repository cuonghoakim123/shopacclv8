<?php
// Set default site name if not defined
if (!isset($site_name)) {
    $site_name = "Shop Accl V8";
}
// Set base url if not defined
if (!isset($base_url)) {
    $base_url = "http://localhost:8080/shopacclv8";
}

// Get current year
$current_year = date('Y');
?>
<footer class="bg-dark text-white pt-5 pb-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
                <h5 class="text-uppercase mb-4"><i class="fas fa-gamepad mr-2"></i><?php echo $site_name; ?></h5>
                <p class="text-muted">
                    Hệ thống mua bán tài khoản game uy tín, chất lượng với giá cả hợp lý. 
                    Chúng tôi cam kết mang đến cho bạn trải nghiệm mua sắm an toàn và thuận tiện nhất.
                </p>
                <div class="mt-4">
                    <a href="#" class="text-white me-4 mr-3 h5">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="text-white me-4 mr-3 h5">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="text-white me-4 mr-3 h5">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="text-white me-4 mr-3 h5">
                        <i class="fab fa-discord"></i>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-2 col-md-6 mb-4 mb-md-0">
                <h5 class="text-uppercase mb-4">Liên kết</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <a href="<?php echo $base_url; ?>/home.php" class="text-white text-decoration-none">
                            <i class="fas fa-angle-right mr-2"></i>Trang chủ
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo $base_url; ?>/shop-account.php" class="text-white text-decoration-none">
                            <i class="fas fa-angle-right mr-2"></i>Tài khoản
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo $base_url; ?>/recharge.php" class="text-white text-decoration-none">
                            <i class="fas fa-angle-right mr-2"></i>Nạp tiền
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="<?php echo $base_url; ?>/orders.php" class="text-white text-decoration-none">
                            <i class="fas fa-angle-right mr-2"></i>Đơn hàng
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                <h5 class="text-uppercase mb-4">Trò chơi</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <a href="#" class="text-white text-decoration-none">
                            <i class="fas fa-gamepad mr-2"></i>Free Fire
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-white text-decoration-none">
                            <i class="fas fa-gamepad mr-2"></i>PUBG Mobile
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-white text-decoration-none">
                            <i class="fas fa-gamepad mr-2"></i>Liên Quân Mobile
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="#" class="text-white text-decoration-none">
                            <i class="fas fa-gamepad mr-2"></i>Genshin Impact
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                <h5 class="text-uppercase mb-4">Liên hệ</h5>
                <ul class="list-unstyled">
                    <li class="mb-3">
                        <i class="fas fa-home mr-2"></i> Hà Nội, Việt Nam
                    </li>
                    <li class="mb-3">
                        <i class="fas fa-envelope mr-2"></i> support@shopacclv8.com
                    </li>
                    <li class="mb-3">
                        <i class="fas fa-phone mr-2"></i> 0123 456 789
                    </li>
                    <li class="mb-3">
                        <i class="fab fa-telegram mr-2"></i> ShopAcclV8_support
                    </li>
                </ul>
            </div>
        </div>
        
        <hr class="my-4">
        
        <div class="row align-items-center">
            <div class="col-md-7 col-lg-8 text-center text-md-left">
                <p class="mb-0">
                    &copy; <?php echo $current_year; ?> <?php echo $site_name; ?>. Tất cả quyền được bảo lưu.
                </p>
            </div>
            <div class="col-md-5 col-lg-4 text-center text-md-right">
                <div class="mb-0">
                    <?php
                    // For now, just use a placeholder image
                    $payment_src = "https://via.placeholder.com/300x40.png?text=Payment+Methods";
                    ?>
                    <img src="<?php echo $payment_src; ?>" alt="Phương thức thanh toán" 
                        class="img-fluid" style="max-height: 40px;">
                </div>
            </div>
        </div>
    </div>
</footer> 