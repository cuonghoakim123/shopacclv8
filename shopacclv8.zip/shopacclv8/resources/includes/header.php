<?php
// Set default site name if not defined
if (!isset($site_name)) {
    $site_name = "Shop Accl V8";
}
// Set base url if not defined
if (!isset($base_url)) {
    $base_url = "";
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : '';
$balance = $isLoggedIn && isset($_SESSION['balance']) ? $_SESSION['balance'] : 0;

// Determine current page for active nav highlighting
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo $base_url; ?>/home.php">
                <i class="fas fa-gamepad mr-2"></i><?php echo $site_name; ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'home' || $current_page == 'index') ? 'active' : ''; ?>" href="<?php echo $base_url; ?>/home.php">
                            <i class="fas fa-home mr-1"></i> Trang chủ
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'shop-account') ? 'active' : ''; ?>" href="<?php echo $base_url; ?>/shop-account.php">
                            <i class="fas fa-store mr-1"></i> Tài khoản
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'recharge') ? 'active' : ''; ?>" href="<?php echo $base_url; ?>/recharge.php">
                            <i class="fas fa-wallet mr-1"></i> Nạp tiền
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == 'orders') ? 'active' : ''; ?>" href="<?php echo $base_url; ?>/orders.php">
                            <i class="fas fa-shopping-cart mr-1"></i> Đơn hàng
                        </a>
                    </li>
                </ul>
                
                <div class="navbar-nav">
                    <?php if ($isLoggedIn): ?>
                        <div class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown">
                                <i class="fas fa-user-circle mr-1"></i> <?php echo safe_html($username); ?>
                                <?php if (isset($balance)): ?>
                                <span class="badge badge-success ml-1"><?php echo number_format($balance); ?> VNĐ</span>
                                <?php endif; ?>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="<?php echo $base_url; ?>/profile.php">
                                    <i class="fas fa-id-card mr-2"></i> Tài khoản của tôi
                                </a>
                                <a class="dropdown-item" href="<?php echo $base_url; ?>/recharge.php">
                                    <i class="fas fa-coins mr-2"></i> Nạp tiền
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="<?php echo $base_url; ?>/home.php?logout=1">
                                    <i class="fas fa-sign-out-alt mr-2"></i> Đăng xuất
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a class="btn btn-outline-light mr-2" href="<?php echo $base_url; ?>/login.php">
                            <i class="fas fa-sign-in-alt mr-1"></i> Đăng nhập
                        </a>
                        <a class="btn btn-primary" href="<?php echo $base_url; ?>/register.php">
                            <i class="fas fa-user-plus mr-1"></i> Đăng ký
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</header> 