/**
 * Modern JavaScript for enhancing the admin dashboard
 * This adds animations, interactions and modern features
 */

document.addEventListener("DOMContentLoaded", function () {
  // Add hover effect to cards
  const cards = document.querySelectorAll(".card");
  cards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-5px)";
      this.style.boxShadow = "0 15px 30px rgba(67, 97, 238, 0.12)";
      this.style.transition = "all 0.3s ease";
    });
    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0)";
      this.style.boxShadow = "0 10px 20px rgba(67, 97, 238, 0.07)";
      this.style.transition = "all 0.3s ease";
    });
  });

  // Add ripple effect to buttons
  const buttons = document.querySelectorAll(".btn");
  buttons.forEach((button) => {
    button.addEventListener("click", function (e) {
      const ripple = document.createElement("span");
      ripple.classList.add("ripple-effect");

      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;

      ripple.style.width = ripple.style.height = size + "px";
      ripple.style.left = x + "px";
      ripple.style.top = y + "px";

      this.appendChild(ripple);

      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });

  // Add smooth scrolling for anchors
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const targetId = this.getAttribute("href");
      if (targetId === "#") return;

      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: "smooth",
        });
      }
    });
  });

  // Add collapsible functionality to sidebar
  const sidebarItems = document.querySelectorAll(
    ".iq-sidebar-menu .side-menu > li > a"
  );
  sidebarItems.forEach((item) => {
    if (item.nextElementSibling && item.nextElementSibling.tagName === "UL") {
      item.addEventListener("click", function (e) {
        const submenu = this.nextElementSibling;
        if (submenu.style.display === "block") {
          submenu.style.display = "none";
          this.classList.remove("active");
        } else {
          submenu.style.display = "block";
          this.classList.add("active");
        }
        e.preventDefault();
      });
    }
  });

  // Add fade in animation for dashboard elements
  const dashboardElements = document.querySelectorAll(
    ".card, .table-container, .chart-container"
  );
  dashboardElements.forEach((element, index) => {
    element.style.opacity = "0";
    element.style.transform = "translateY(20px)";
    element.style.transition = "opacity 0.5s ease, transform 0.5s ease";

    setTimeout(() => {
      element.style.opacity = "1";
      element.style.transform = "translateY(0)";
    }, 100 * index);
  });

  // Enhance tables with sorting and search functionality
  const tables = document.querySelectorAll(".table");
  tables.forEach((table) => {
    if (!table.classList.contains("no-sort")) {
      const headers = table.querySelectorAll("th");
      headers.forEach((header) => {
        if (!header.classList.contains("no-sort")) {
          header.style.cursor = "pointer";
          header.addEventListener("click", function () {
            const columnIndex = Array.from(headers).indexOf(this);
            sortTableByColumn(table, columnIndex);
          });
        }
      });
    }
  });

  // Add dark mode toggle functionality
  const darkModeToggle = document.getElementById("dark-mode-toggle");
  if (darkModeToggle) {
    darkModeToggle.addEventListener("click", function () {
      document.body.classList.toggle("dark");

      // Save preference to localStorage
      if (document.body.classList.contains("dark")) {
        localStorage.setItem("darkMode", "enabled");
      } else {
        localStorage.setItem("darkMode", "disabled");
      }
    });

    // Check for saved preference
    if (localStorage.getItem("darkMode") === "enabled") {
      document.body.classList.add("dark");
    }
  }
});

// Table sorting function
function sortTableByColumn(table, column, asc = true) {
  const dirModifier = asc ? 1 : -1;
  const tBody = table.tBodies[0];
  const rows = Array.from(tBody.querySelectorAll("tr"));

  // Sort each row
  const sortedRows = rows.sort((a, b) => {
    const aColText = a.cells[column].textContent.trim();
    const bColText = b.cells[column].textContent.trim();

    // Check if the content is numeric
    const aColNum = parseFloat(aColText.replace(/[^\d.-]/g, ""));
    const bColNum = parseFloat(bColText.replace(/[^\d.-]/g, ""));

    if (!isNaN(aColNum) && !isNaN(bColNum)) {
      return aColNum > bColNum ? 1 * dirModifier : -1 * dirModifier;
    } else {
      return aColText > bColText ? 1 * dirModifier : -1 * dirModifier;
    }
  });

  // Remove all existing rows from the table
  while (tBody.firstChild) {
    tBody.removeChild(tBody.firstChild);
  }

  // Add sorted rows
  tBody.append(...sortedRows);

  // Remember sorting direction
  table
    .querySelectorAll("th")
    .forEach((th) => th.classList.remove("th-sort-asc", "th-sort-desc"));
  table
    .querySelector(`th:nth-child(${column + 1})`)
    .classList.toggle("th-sort-asc", asc);
  table
    .querySelector(`th:nth-child(${column + 1})`)
    .classList.toggle("th-sort-desc", !asc);
}
