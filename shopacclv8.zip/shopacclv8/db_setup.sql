-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS shopacclv8 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shopacclv8;

-- Bảng người dùng
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    balance DECIMAL(15,2) DEFAULT 0,
    discount_percent INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Bảng danh mục sản phẩm
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(255),
    description TEXT,
    status TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng sản phẩm
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(255) NOT NULL,
    image VARCHAR(255),
    price DECIMAL(15,2) NOT NULL,
    description TEXT,
    stock INT DEFAULT 0,
    sold INT DEFAULT 0,
    status TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Bảng tài khoản game
CREATE TABLE IF NOT EXISTS accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    account_data TEXT NOT NULL,
    price DECIMAL(15,2) NOT NULL,
    status TINYINT DEFAULT 1, -- 1: available, 0: sold
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Bảng đơn hàng
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    transaction_code VARCHAR(50) NOT NULL,
    status TINYINT DEFAULT 1, -- 1: completed, 0: cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Bảng chi tiết đơn hàng
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    account_id INT NOT NULL,
    product_id INT NOT NULL,
    price DECIMAL(15,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Bảng lịch sử nạp tiền
CREATE TABLE IF NOT EXISTS deposits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    transaction_code VARCHAR(50) NOT NULL,
    status TINYINT DEFAULT 0, -- 0: pending, 1: completed, 2: cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Bảng cài đặt hệ thống
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Thêm dữ liệu mẫu

-- Thêm tài khoản admin
INSERT INTO users (username, password, email, balance, discount_percent) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@shopacclv8.top', 1000000, 0);

-- Thêm danh mục sản phẩm
INSERT INTO categories (name, description, status) VALUES
('Tài khoản FF Lv5', 'Tài khoản Free Fire level 5', 1),
('Tài khoản FF Lv8', 'Tài khoản Free Fire level 8', 1),
('Tài khoản FF Login Google', 'Tài khoản Free Fire đăng nhập bằng Google', 1),
('Tài khoản FF Login Facebook', 'Tài khoản Free Fire đăng nhập bằng Facebook', 1);

-- Thêm sản phẩm
INSERT INTO products (category_id, name, price, description, stock, sold, status) VALUES
(1, 'Tài khoản FF Lv5 Giá Rẻ', 50000, 'Tài khoản Free Fire level 5, đã đăng ký đầy đủ thông tin', 100, 20, 1),
(2, 'Tài khoản FF Lv8 Giá Rẻ', 100000, 'Tài khoản Free Fire level 8, đã đăng ký đầy đủ thông tin', 50, 10, 1),
(3, 'Tài khoản FF Login Google', 150000, 'Tài khoản Free Fire đăng nhập bằng Google, bảo mật cao', 30, 5, 1),
(4, 'Tài khoản FF Login Facebook', 120000, 'Tài khoản Free Fire đăng nhập bằng Facebook, bảo mật cao', 40, 8, 1);

-- Thêm tài khoản game
INSERT INTO accounts (product_id, account_data, price, status) VALUES
(1, '{"username":"fflv5_001", "password":"pass001", "type":"FF Lv5"}', 50000, 1),
(1, '{"username":"fflv5_002", "password":"pass002", "type":"FF Lv5"}', 50000, 1),
(1, '{"username":"fflv5_003", "password":"pass003", "type":"FF Lv5"}', 50000, 1),
(2, '{"username":"fflv8_001", "password":"pass004", "type":"FF Lv8"}', 100000, 1),
(2, '{"username":"fflv8_002", "password":"pass005", "type":"FF Lv8"}', 100000, 1),
(3, '{"username":"ffgg_001", "password":"pass006", "type":"FF Login Google"}', 150000, 1),
(3, '{"username":"ffgg_002", "password":"pass007", "type":"FF Login Google"}', 150000, 1),
(4, '{"username":"fffb_001", "password":"pass008", "type":"FF Login Facebook"}', 120000, 1);

-- Thêm cài đặt hệ thống
INSERT INTO settings (setting_key, setting_value) VALUES
('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG'),
('site_description', 'Shop Bán Acc Free Fire Lv5, Lv8 Giá Rẻ, Login Google, Login Twitter'),
('site_keywords', 'bán acc ff lv5, lv8 giá rẻ, log gg, log tw giá rẻ'),
('site_logo', 'assets/storage/images/5.jpg'),
('site_favicon', 'assets/storage/images/favicon_UPQ.png'),
('currency', 'VNĐ'),
('maintenance_mode', '0'); 