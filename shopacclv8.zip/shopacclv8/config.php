<?php
// Database Configuration
$db_host = 'localhost'; 
$db_name = 'shop_accl_v8';  
$db_user = 'root';       
$db_pass = '';           

// Site Configuration
$site_name = "Shop Accl V8";
$base_url = "http://localhost:8080"; // Set the base URL for local development

// Debug mode (set to false in production)
$debug = true;

// Time zone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Session configuration - only set if session hasn't started yet
if (session_status() == PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
}

// Error reporting
if ($debug) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

// Define constants
define('APP_ROOT', dirname(__FILE__));
define('URL_ROOT', $base_url);
define('APP_NAME', $site_name);

// Include database connection
require_once 'database.php';

// Common functions
function redirect($url) {
    header("Location: $url");
    exit();
}

function validateInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function getCurrentUserId() {
    if (isset($_SESSION['user_id'])) {
        return $_SESSION['user_id'];
    }
    return false;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function generateTransactionCode() {
    return strtoupper(uniqid() . generateRandomString(6));
}

function formatMoney($amount) {
    return number_format($amount, 0, ',', '.') . 'đ';
}

// You can add more configuration settings here as needed
?> 