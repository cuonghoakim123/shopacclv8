<?php
// Start session if not already started
if (function_exists('session_status')) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
} else {
    session_start(); // Fallback for older PHP versions
}

// Define configuration variables
$site_name = "Shop Accl V8";
$base_url = "http://localhost:8080/shopacclv8";
$page_title = "Trang Chủ";

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : '';

// Function to safely escape HTML
function safe_html($str) {
    if (function_exists('htmlspecialchars')) {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
    return str_replace(['&', '<', '>', '"', "'"], ['&amp;', '&lt;', '&gt;', '&quot;', '&#39;'], $str);
}

// Function to format numbers
function safe_number_format($number) {
    if (function_exists('number_format')) {
        return number_format($number);
    }
    return $number;
}

// Demo products data
$products = [
    [
        'id' => 1,
        'name' => 'ACCOUNT FF MAX LV8',
        'price' => 150000,
        'description' => 'Tài khoản Free Fire Max Level 8, đầy đủ trang phục và vũ khí',
        'image' => 'https://via.placeholder.com/350x200.png?text=Free+Fire+Account+LV8'
    ],
    [
        'id' => 2,
        'name' => 'ACCOUNT FF LV5',
        'price' => 100000,
        'description' => 'Tài khoản Free Fire Level 5, nhiều trang phục hiếm',
        'image' => 'https://via.placeholder.com/350x200.png?text=Free+Fire+Account+LV5'
    ],
    [
        'id' => 3,
        'name' => 'ACCOUNT FF VIP',
        'price' => 200000,
        'description' => 'Tài khoản Free Fire VIP, full trang phục và pet',
        'image' => 'https://via.placeholder.com/350x200.png?text=Free+Fire+VIP+Account'
    ],
    [
        'id' => 4,
        'name' => 'ACCOUNT PUBG MOBILE',
        'price' => 180000,
        'description' => 'Tài khoản PUBG Mobile cấp cao, nhiều skin súng',
        'image' => 'https://via.placeholder.com/350x200.png?text=PUBG+Mobile+Account'
    ]
];

// Featured games
$featured_games = [
    ['name' => 'Free Fire', 'icon' => 'fire', 'color' => 'danger'],
    ['name' => 'PUBG Mobile', 'icon' => 'crosshairs', 'color' => 'warning'],
    ['name' => 'Liên Quân Mobile', 'icon' => 'crown', 'color' => 'primary'],
    ['name' => 'Genshin Impact', 'icon' => 'gem', 'color' => 'info']
];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo $site_name; ?></title>
    
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <?php include 'resources/includes/header.php'; ?>

    <!-- Hero Banner with Animated Content -->
    <section class="jumbotron text-center">
        <div class="container hero-content">
            <h1 class="display-4 animate__animated animate__fadeInDown">Chào mừng đến với <?php echo $site_name; ?></h1>
            <p class="lead animate__animated animate__fadeInUp animate__delay-1s">Hệ thống mua bán tài khoản game uy tín, chất lượng, giá tốt nhất thị trường</p>
            <?php if (!$isLoggedIn): ?>
            <div class="mt-4 animate__animated animate__fadeInUp animate__delay-2s">
                <a href="<?php echo $base_url; ?>/login.php" class="btn btn-light btn-lg mr-2">
                    <i class="fas fa-sign-in-alt mr-2"></i>Đăng nhập
                </a>
                <a href="<?php echo $base_url; ?>/register.php" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-user-plus mr-2"></i>Đăng ký
                </a>
            </div>
            <?php else: ?>
            <p class="animate__animated animate__fadeInUp animate__delay-2s">Chào <strong><?php echo safe_html($username); ?></strong>, chúc bạn một ngày tốt lành!</p>
            <div class="mt-3 animate__animated animate__fadeInUp animate__delay-2s">
                <a href="<?php echo $base_url; ?>/shop-account.php" class="btn btn-light btn-lg">
                    <i class="fas fa-shopping-cart mr-2"></i>Mua ngay
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Main Content -->
    <main class="container py-5">
        <!-- Game Categories Section -->
        <section class="mb-5">
            <h2 class="text-center mb-4 fancy-heading">Danh mục game</h2>
            <div class="row justify-content-center">
                <?php foreach ($featured_games as $game): ?>
                <div class="col-lg-3 col-md-6">
                    <div class="game-category">
                        <div class="game-icon text-<?php echo $game['color']; ?>">
                            <i class="fas fa-<?php echo $game['icon']; ?>"></i>
                        </div>
                        <h4><?php echo $game['name']; ?></h4>
                        <p class="text-muted">Tài khoản chất lượng cao</p>
                        <a href="#" class="btn btn-sm btn-outline-<?php echo $game['color']; ?>">Xem tài khoản</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        
        <!-- Category Navigation -->
        <section class="mb-5">
            <h2 class="text-center mb-4 fancy-heading">Tài khoản nổi bật</h2>
            <div class="text-center mb-4">
                <ul class="nav nav-pills justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Tất cả</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Free Fire</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">PUBG Mobile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Liên Quân Mobile</a>
                    </li>
                </ul>
            </div>
            
            <!-- Products -->
            <div class="row">
                <?php foreach ($products as $product): ?>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card product-card h-100">
                        <div class="product-badge">
                            <span class="badge badge-danger">Hot</span>
                        </div>
                        <img src="<?php echo $product['image']; ?>" class="card-img-top product-image" alt="<?php echo safe_html($product['name']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo safe_html($product['name']); ?></h5>
                            <p class="card-text text-danger font-weight-bold"><?php echo safe_number_format($product['price']); ?> VNĐ</p>
                            <p class="card-text small"><?php echo safe_html($product['description']); ?></p>
                        </div>
                        <div class="card-footer bg-white border-top-0">
                            <a href="<?php echo $base_url; ?>/product.php?id=<?php echo $product['id']; ?>" class="btn btn-primary btn-block">
                                <i class="fas fa-eye mr-2"></i>Xem chi tiết
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-4">
                <a href="<?php echo $base_url; ?>/shop-account.php" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-store mr-2"></i>Xem tất cả tài khoản
                </a>
            </div>
        </section>
        
        <!-- Stats Section -->
        <section class="py-5 bg-light rounded my-5">
            <div class="container">
                <h2 class="text-center mb-5 fancy-heading">Tại sao chọn chúng tôi?</h2>
                <div class="row text-center">
                    <div class="col-md-3 col-6">
                        <div class="counter-box">
                            <i class="fas fa-users fa-3x text-primary mb-3"></i>
                            <div class="counter-number">15,000+</div>
                            <h5>Khách hàng</h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="counter-box">
                            <i class="fas fa-shopping-cart fa-3x text-success mb-3"></i>
                            <div class="counter-number">30,000+</div>
                            <h5>Giao dịch</h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="counter-box">
                            <i class="fas fa-gamepad fa-3x text-danger mb-3"></i>
                            <div class="counter-number">5,000+</div>
                            <h5>Tài khoản</h5>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="counter-box">
                            <i class="fas fa-headset fa-3x text-warning mb-3"></i>
                            <div class="counter-number">24/7</div>
                            <h5>Hỗ trợ</h5>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Features Section -->
        <section class="mb-5">
            <h2 class="text-center mb-4 fancy-heading">Dịch vụ của chúng tôi</h2>
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-4 feature-icon">
                                <i class="fas fa-shield-alt fa-4x text-primary"></i>
                            </div>
                            <h4 class="card-title">Bảo mật tuyệt đối</h4>
                            <p class="card-text">Thông tin tài khoản và khách hàng được bảo mật 100%, đảm bảo an toàn cho người dùng.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-4 feature-icon">
                                <i class="fas fa-money-bill-wave fa-4x text-success"></i>
                            </div>
                            <h4 class="card-title">Giá cả hợp lý</h4>
                            <p class="card-text">Cam kết mức giá tốt nhất thị trường với chất lượng tài khoản đảm bảo.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="mb-4 feature-icon">
                                <i class="fas fa-headset fa-4x text-danger"></i>
                            </div>
                            <h4 class="card-title">Hỗ trợ 24/7</h4>
                            <p class="card-text">Đội ngũ hỗ trợ chuyên nghiệp, sẵn sàng giải đáp mọi thắc mắc và hỗ trợ khách hàng.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Testimonials -->
        <section class="mb-5">
            <h2 class="text-center mb-4 fancy-heading">Đánh giá từ khách hàng</h2>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="testimonial">
                        <div class="d-flex align-items-center mb-3">
                            <img src="https://via.placeholder.com/60x60.png?text=Avatar" class="testimonial-avatar" alt="Customer Avatar">
                            <div>
                                <h5 class="mb-0">Nguyễn Văn A</h5>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                            </div>
                        </div>
                        <p>"Dịch vụ quá tốt, tài khoản ưng ý, giá cả hợp lý. Mình đã mua rất nhiều lần và luôn hài lòng. Sẽ tiếp tục ủng hộ shop!"</p>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="testimonial">
                        <div class="d-flex align-items-center mb-3">
                            <img src="https://via.placeholder.com/60x60.png?text=Avatar" class="testimonial-avatar" alt="Customer Avatar">
                            <div>
                                <h5 class="mb-0">Trần Thị B</h5>
                                <div class="text-warning">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                </div>
                            </div>
                        </div>
                        <p>"Shop phục vụ rất chuyên nghiệp, tư vấn nhiệt tình. Tài khoản mình mua đúng như mô tả, rất hài lòng và sẽ giới thiệu cho bạn bè."</p>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- CTA Section -->
        <section class="bg-primary text-white p-5 rounded">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h3>Bạn đã sẵn sàng để trải nghiệm?</h3>
                    <p class="mb-md-0">Đăng ký ngay hôm nay để nhận ưu đãi đặc biệt dành cho thành viên mới!</p>
                </div>
                <div class="col-md-4 text-md-right">
                    <a href="<?php echo $base_url; ?>/register.php" class="btn btn-light btn-lg">
                        <i class="fas fa-user-plus mr-2"></i>Đăng ký ngay
                    </a>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include 'resources/includes/footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Custom JS -->
    <script>
    $(document).ready(function() {
        // Add animation to elements when they come into view
        function animateOnScroll() {
            $('.counter-box, .game-category, .card, .testimonial').each(function() {
                var elementPosition = $(this).offset().top;
                var viewportBottom = $(window).scrollTop() + $(window).height();
                
                if (elementPosition < viewportBottom) {
                    $(this).addClass('animate__animated animate__fadeInUp');
                }
            });
        }
        
        // Run once on page load
        animateOnScroll();
        
        // Run on scroll
        $(window).scroll(function() {
            animateOnScroll();
        });
        
        // Smooth scrolling for navigation links
        $('a[href*="#"]').on('click', function(e) {
            e.preventDefault();
            
            $('html, body').animate(
                {
                    scrollTop: $($(this).attr('href')).offset().top - 100,
                },
                500,
                'linear'
            );
        });
    });
    </script>
</body>
</html>
