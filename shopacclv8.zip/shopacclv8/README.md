# ShopAccLv8 - Cửa Hàng Tài Khoản FF

## Cài Đặt

1. Copy tất cả các file vào thư mục `shopacclv8` trong document root của web server
2. Đảm bảo rằng web server của bạn (Apache) đã bật mod_rewrite
3. Đảm bảo thư mục có quyền đọc/ghi phù hợp
4. Truy cập trang web qua: http://localhost:8080/shopacclv8

## Cấu Hình

Nếu bạn muốn thay đổi URL cơ sở, hãy chỉnh sửa file `config.php`:

```php
$base_url = 'http://localhost:8080/shopacclv8';
```

Thay thế URL bằng URL bạn muốn sử dụng.

## Chức Năng

- Đăng nhập / Đăng ký
- Trang chủ với thông tin tài khoản
- Xem sản phẩm

## Thông Tin Đăng Nhập

Đây là phiên bản demo, bạn có thể đăng nhập với bất kỳ tên người dùng và mật khẩu nào.
