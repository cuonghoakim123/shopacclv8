<?php
// Simple test file
echo "<h1>PHP is working!</h1>";
echo "<p>Current time: " . date("Y-m-d H:i:s") . "</p>";
phpinfo();
?> 