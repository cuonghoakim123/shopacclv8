<?php
session_start();
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Lấy thông tin người dùng từ database
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Lấy danh sách top người dùng chi tiêu nhiều nhất
$top_users = findAll("SELECT 
                        u.id,
                        u.username,
                        COALESCE(SUM(o.total_amount), 0) as total_spent,
                        COUNT(o.id) as order_count,
                        (SELECT MAX(o2.created_at) FROM orders o2 WHERE o2.user_id = u.id AND o2.status = 1) as last_order
                      FROM users u
                      LEFT JOIN orders o ON u.id = o.user_id AND o.status = 1
                      GROUP BY u.id
                      ORDER BY total_spent DESC, order_count DESC
                      LIMIT 20");

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.png');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Bảng Xếp Hạng - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/responsive.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Roboto', sans-serif;    
    }

    .iq-sidebar {
        background: linear-gradient(#12214E, #12214E, #013B7B);
    }

    .change-mode .custom-switch.custom-switch-icon label.custom-control-label:after {
        top: 0;
        left: 0;
        width: 35px;
        height: 30px;
        border-radius: 5px 0 0 5px;
        background-color: #12214E;
        border-color: #12214E;
        z-index: 0;
    }
    
    .ranking-badge {
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        color: white;
        font-weight: bold;
    }
    
    .rank-1 {
        background-color: #FFD700; /* Gold */
    }
    
    .rank-2 {
        background-color: #C0C0C0; /* Silver */
    }
    
    .rank-3 {
        background-color: #CD7F32; /* Bronze */
    }
    
    .rank-other {
        background-color: #6c757d; /* Default gray */
    }
    
    .current-user {
        background-color: #f8f9fa;
    }
    </style>
</head>
<body class="color-light">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="iq-sidebar sidebar-default">
            <div class="iq-sidebar-logo d-flex align-items-end justify-content-between">
                <a href="<?php echo $base_url; ?>/home.php" class="header-logo">
                    <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="img-fluid rounded-normal light-logo" alt="logo">
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <li class="px-3 pt-3 pb-2">
                            <span class="text-uppercase small font-weight-bold">Số Dư <span style="color: yellow;"><?php echo formatMoney($balance); ?></span> - Giảm: <span style="color: red;"><?php echo $discount; ?>%</span>
                            </span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php" class="svg-icon">
                                <i class="fas fa-home"></i>
                                <span class="ml-2">Bảng Điều Khiển</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/shop-account.php" class="svg-icon">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="ml-2">Mua Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/orders.php" class="svg-icon">
                                <i class="fas fa-history"></i>
                                <span class="ml-2">Lịch Sử Mua Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/top-money.php" class="svg-icon active">
                                <i class="fas fa-trophy"></i>
                                <span class="ml-2">Bảng Xếp Hạng</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Nạp Tiền</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/recharge.php" class="svg-icon">
                                <i class="fas fa-university"></i>
                                <span class="ml-2">Ngân Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/invoices.php" class="svg-icon">
                                <i class="fas fa-file-invoice"></i>
                                <span class="ml-2">Hoá Đơn</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/nap-the.php" class="svg-icon">
                                <i class="fas fa-credit-card"></i>
                                <span class="ml-2">Nạp Thẻ</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Tài Khoản</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/profile.php" class="svg-icon">
                                <i class="fas fa-user-edit"></i>
                                <span class="ml-2">Thông Tin Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php?logout=1" class="svg-icon">
                                <i class="fas fa-sign-out-alt"></i>
                                <span class="ml-2">Đăng Xuất</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Bảng Xếp Hạng Chi Tiêu</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle"></i> Bảng xếp hạng được cập nhật theo thời gian thực dựa trên tổng số tiền chi tiêu của người dùng trên hệ thống.
                                </div>
                                
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th width="80px">Hạng</th>
                                                <th>Tên người dùng</th>
                                                <th>Tổng chi tiêu</th>
                                                <th>Số đơn hàng</th>
                                                <th>Đơn hàng gần nhất</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($top_users as $index => $top_user): ?>
                                            <tr class="<?php echo ($top_user['id'] == $user_id) ? 'current-user' : ''; ?>">
                                                <td class="text-center">
                                                    <div class="ranking-badge rank-<?php echo ($index < 3) ? ($index + 1) : 'other'; ?> mx-auto">
                                                        <?php echo $index + 1; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo htmlspecialchars($top_user['username']); ?>
                                                    <?php if($top_user['id'] == $user_id): ?>
                                                    <span class="badge badge-primary">Bạn</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo formatMoney($top_user['total_spent']); ?></td>
                                                <td><?php echo number_format($top_user['order_count']); ?></td>
                                                <td>
                                                    <?php echo $top_user['last_order'] ? date('d/m/Y H:i', strtotime($top_user['last_order'])) : 'Chưa có đơn hàng'; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            
                                            <?php if(count($top_users) == 0): ?>
                                            <tr>
                                                <td colspan="5" class="text-center">Chưa có dữ liệu</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo $base_url; ?>/public/js/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });
        });
    </script>
</body>
</html> 