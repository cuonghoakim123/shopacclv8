<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Lấy thông tin người dùng từ database
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$email = $user['email'] ?? '';
$balance = $user['balance'];
$discount = $user['discount_percent'];
$created_at = $user['created_at'];

// Xử lý cập nhật thông tin tài khoản
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Cập nhật thông tin cơ bản
    if (isset($_POST['update_info'])) {
        $new_email = validateInput($_POST['email']);
        
        // Kiểm tra email hợp lệ
        if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Email không hợp lệ.';
            $message_type = 'danger';
        } else {
            // Kiểm tra email đã tồn tại
            $check_email = find("SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1", 
                            ['email' => $new_email, 'id' => $user_id]);
            
            if ($check_email && $new_email != $email) {
                $message = 'Email đã được sử dụng bởi tài khoản khác.';
                $message_type = 'danger';
            } else {
                // Cập nhật thông tin
                $result = update('users', 
                                ['email' => $new_email], 
                                'id = :id', 
                                ['id' => $user_id]);
                
                if ($result) {
                    $email = $new_email;
                    $message = 'Cập nhật thông tin thành công.';
                    $message_type = 'success';
                } else {
                    $message = 'Có lỗi xảy ra, vui lòng thử lại sau.';
                    $message_type = 'danger';
                }
            }
        }
    }
    
    // Đổi mật khẩu
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Kiểm tra mật khẩu mới
        if (strlen($new_password) < 6) {
            $message = 'Mật khẩu mới phải có ít nhất 6 ký tự.';
            $message_type = 'danger';
        } elseif ($new_password !== $confirm_password) {
            $message = 'Mật khẩu xác nhận không khớp.';
            $message_type = 'danger';
        } else {
            // Kiểm tra mật khẩu hiện tại
            if (!password_verify($current_password, $user['password'])) {
                $message = 'Mật khẩu hiện tại không chính xác.';
                $message_type = 'danger';
            } else {
                // Cập nhật mật khẩu mới
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $result = update('users', 
                                ['password' => $hashed_password], 
                                'id = :id', 
                                ['id' => $user_id]);
                
                if ($result) {
                    $message = 'Đổi mật khẩu thành công.';
                    $message_type = 'success';
                } else {
                    $message = 'Có lỗi xảy ra, vui lòng thử lại sau.';
                    $message_type = 'danger';
                }
            }
        }
    }
}

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.png');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Thông Tin Tài Khoản - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/responsive.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Roboto', sans-serif;    
    }

    .iq-sidebar {
        background: linear-gradient(#12214E, #12214E, #013B7B);
    }

    .change-mode .custom-switch.custom-switch-icon label.custom-control-label:after {
        top: 0;
        left: 0;
        width: 35px;
        height: 30px;
        border-radius: 5px 0 0 5px;
        background-color: #12214E;
        border-color: #12214E;
        z-index: 0;
    }
    </style>
</head>
<body class="color-light">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="iq-sidebar sidebar-default">
            <div class="iq-sidebar-logo d-flex align-items-end justify-content-between">
                <a href="<?php echo $base_url; ?>/home.php" class="header-logo">
                    <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="img-fluid rounded-normal light-logo" alt="logo">
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <li class="px-3 pt-3 pb-2">
                            <span class="text-uppercase small font-weight-bold">Số Dư <span style="color: yellow;"><?php echo formatMoney($balance); ?></span> - Giảm: <span style="color: red;"><?php echo $discount; ?>%</span>
                            </span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php" class="svg-icon">
                                <i class="fas fa-home"></i>
                                <span class="ml-2">Bảng Điều Khiển</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/shop-account.php" class="svg-icon">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="ml-2">Mua Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/orders.php" class="svg-icon">
                                <i class="fas fa-history"></i>
                                <span class="ml-2">Lịch Sử Mua Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/top-money.php" class="svg-icon">
                                <i class="fas fa-trophy"></i>
                                <span class="ml-2">Bảng Xếp Hạng</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Nạp Tiền</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/recharge.php" class="svg-icon">
                                <i class="fas fa-university"></i>
                                <span class="ml-2">Ngân Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/invoices.php" class="svg-icon">
                                <i class="fas fa-file-invoice"></i>
                                <span class="ml-2">Hoá Đơn</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/nap-the.php" class="svg-icon">
                                <i class="fas fa-credit-card"></i>
                                <span class="ml-2">Nạp Thẻ</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Tài Khoản</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/profile.php" class="svg-icon active">
                                <i class="fas fa-user-edit"></i>
                                <span class="ml-2">Thông Tin Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php?logout=1" class="svg-icon">
                                <i class="fas fa-sign-out-alt"></i>
                                <span class="ml-2">Đăng Xuất</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <!-- Thông tin tài khoản -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Thông Tin Tài Khoản</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if(!empty($message)): ?>
                                <div class="alert alert-<?php echo $message_type; ?>">
                                    <i class="fas fa-info-circle"></i> <?php echo $message; ?>
                                </div>
                                <?php endif; ?>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-header">
                                                <h5 class="card-title">Thông Tin Cơ Bản</h5>
                                            </div>
                                            <div class="card-body">
                                                <form method="POST" action="">
                                                    <div class="form-group">
                                                        <label for="username">Tên đăng nhập:</label>
                                                        <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($username); ?>" readonly>
                                                        <small class="text-muted">Tên đăng nhập không thể thay đổi</small>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="email">Email:</label>
                                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Số dư tài khoản:</label>
                                                        <input type="text" class="form-control" value="<?php echo formatMoney($balance); ?>" readonly>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Giảm giá:</label>
                                                        <input type="text" class="form-control" value="<?php echo $discount; ?>%" readonly>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Ngày đăng ký:</label>
                                                        <input type="text" class="form-control" value="<?php echo date('d/m/Y H:i', strtotime($created_at)); ?>" readonly>
                                                    </div>
                                                    <button type="submit" name="update_info" class="btn btn-primary">
                                                        <i class="fas fa-save"></i> Cập Nhật Thông Tin
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="card">
                                            <div class="card-header">
                                                <h5 class="card-title">Đổi Mật Khẩu</h5>
                                            </div>
                                            <div class="card-body">
                                                <form method="POST" action="">
                                                    <div class="form-group">
                                                        <label for="current_password">Mật khẩu hiện tại:</label>
                                                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="new_password">Mật khẩu mới:</label>
                                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                                        <small class="text-muted">Mật khẩu phải có ít nhất 6 ký tự</small>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="confirm_password">Xác nhận mật khẩu mới:</label>
                                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                                    </div>
                                                    <button type="submit" name="change_password" class="btn btn-warning">
                                                        <i class="fas fa-key"></i> Đổi Mật Khẩu
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        
                                        <div class="card mt-3">
                                            <div class="card-header">
                                                <h5 class="card-title">Bảo Mật Tài Khoản</h5>
                                            </div>
                                            <div class="card-body">
                                                <div class="alert alert-info">
                                                    <i class="fas fa-shield-alt"></i> Lưu ý bảo mật:
                                                    <ul class="mb-0">
                                                        <li>Không chia sẻ mật khẩu với người khác</li>
                                                        <li>Sử dụng mật khẩu mạnh và khác nhau cho các tài khoản khác nhau</li>
                                                        <li>Đổi mật khẩu định kỳ để tăng cường bảo mật</li>
                                                        <li>Đảm bảo thiết bị của bạn không bị nhiễm mã độc</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo $base_url; ?>/public/js/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });
        });
    </script>
</body>
</html> 