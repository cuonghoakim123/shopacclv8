<?php
// Check if required extensions are loaded
if (!extension_loaded('session')) {
    die('PHP Session extension is required.');
}

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';
require_once 'database.php';

// Set default values if not defined in config.php
if (!isset($site_name)) {
    $site_name = "Shop Accl V8";
}
if (!isset($base_url)) {
    $base_url = "";
}

// Page title
$page_title = "Đăng Nhập";

// Check if already logged in
if (isLoggedIn()) {
    redirect($base_url . '/home.php');
}

// Handle login submission
$error_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = validateInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Basic validation
    if (empty($username) || empty($password)) {
        $error_message = 'Vui lòng điền đầy đủ thông tin đăng nhập.';
    } else {
        // Find user in database
        $user = find("SELECT * FROM users WHERE username = :username LIMIT 1", ['username' => $username]);
        
        if ($user && password_verify($password, $user['password'])) {
            // Login successful
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_balance'] = $user['balance'];
            $_SESSION['discount_percent'] = $user['discount_percent'];
            
            // Redirect to home page
            redirect($base_url . '/home.php');
        } else {
            $error_message = 'Tên đăng nhập hoặc mật khẩu không đúng.';
        }
    }
}

// Kiểm tra thông báo đăng xuất thành công
$logout_success = isset($_GET['logout']) && $_GET['logout'] == 1;
$logout_username = isset($_GET['username']) ? (function_exists('urldecode') ? urldecode($_GET['username']) : $_GET['username']) : '';

// Function to safely escape HTML if htmlspecialchars is not available
if (!function_exists('safe_html')) {
    function safe_html($str) {
        if (function_exists('htmlspecialchars')) {
            return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
        }
        return str_replace(['&', '<', '>', '"', "'"], ['&amp;', '&lt;', '&gt;', '&quot;', '&#39;'], $str);
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $site_favicon; ?>" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" 
          integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" 
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        :root {
            --primary-color: #013B7B;
            --secondary-color: #12214E;
            --accent-color: #FF9900;
            --light-bg: #f4f6fc;
            --font-family: 'Poppins', sans-serif;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        body {
            font-family: var(--font-family);
            background: var(--light-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-wrapper {
            width: 100%;
            max-width: 450px;
        }
        
        .card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: var(--shadow);
            border: none;
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px;
            text-align: center;
            border-bottom: none;
        }
        
        .card-body {
            padding: 30px;
        }
        
        .form-control {
            border-radius: 30px;
            padding: 12px 20px;
            height: auto;
            box-shadow: none;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            box-shadow: 0 0 10px rgba(1, 59, 123, 0.1);
            border-color: var(--primary-color);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 30px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: var(--accent-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(1, 59, 123, 0.2);
        }
        
        .logo {
            display: block;
            margin: 0 auto 20px;
            max-width: 120px;
            border-radius: 15px;
            transition: all 0.3s ease;
        }
        
        .logo:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        a {
            color: var(--primary-color);
            transition: all 0.3s ease;
        }
        
        a:hover {
            color: var(--accent-color);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="text-center mb-4">
            <img src="<?php echo $site_logo; ?>" alt="<?php echo $site_name; ?>" class="logo">
            <h2 class="text-primary font-weight-bold"><?php echo $site_name; ?></h2>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Đăng Nhập</h4>
            </div>
            <div class="card-body">
                <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($logout_success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Bạn đã đăng xuất thành công!
                </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="username">Tên đăng nhập</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Mật khẩu</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">Ghi nhớ đăng nhập</label>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="submit" name="login" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt mr-2"></i>Đăng Nhập
                        </button>
                        <a href="register.php" class="text-decoration-none">Chưa có tài khoản? Đăng ký</a>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <p class="text-muted">&copy; <?php echo date('Y'); ?> <?php echo $site_name; ?>. All Rights Reserved.</p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 