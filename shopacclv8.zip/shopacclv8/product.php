<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Lấy ID sản phẩm
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($product_id <= 0) {
    redirect($base_url . '/shop-account.php');
}

// Lấy thông tin người dùng từ database
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Lấy thông tin sản phẩm
$product = find("SELECT p.*, c.name as category_name, COUNT(a.id) AS available_accounts 
                FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id
                LEFT JOIN accounts a ON p.id = a.product_id AND a.status = 1
                WHERE p.id = :id AND p.status = 1
                GROUP BY p.id", ['id' => $product_id]);

if (!$product) {
    redirect($base_url . '/shop-account.php');
}

// Tính giá sau khi giảm giá
$discounted_price = $product['price'] * (1 - $discount / 100);

// Xử lý mua sản phẩm
$success_message = '';
$error_message = '';

if (isset($_POST['buy_product'])) {
    // Kiểm tra số dư
    if ($balance < $discounted_price) {
        $error_message = "Số dư không đủ để thực hiện giao dịch. Vui lòng nạp thêm tiền.";
    } elseif ($product['available_accounts'] <= 0) {
        $error_message = "Sản phẩm đã hết hàng.";
    } else {
        // Lấy tài khoản game còn trống
        $account = find("SELECT * FROM accounts WHERE product_id = :product_id AND status = 1 LIMIT 1", ['product_id' => $product_id]);
        
        if (!$account) {
            $error_message = "Không tìm thấy tài khoản phù hợp.";
        } else {
            // Bắt đầu transaction
            $conn = getDbConnection();
            $conn->beginTransaction();
            
            try {
                // Tạo mã giao dịch
                $transaction_code = generateTransactionCode();
                
                // Tạo đơn hàng
                $order_data = [
                    'user_id' => $user_id,
                    'total_amount' => $discounted_price,
                    'transaction_code' => $transaction_code,
                    'status' => 1
                ];
                
                $order_id = insert('orders', $order_data);
                
                // Tạo chi tiết đơn hàng
                $order_item_data = [
                    'order_id' => $order_id,
                    'account_id' => $account['id'],
                    'product_id' => $product_id,
                    'price' => $discounted_price
                ];
                
                insert('order_items', $order_item_data);
                
                // Cập nhật trạng thái tài khoản
                update('accounts', ['status' => 0], 'id = :id', ['id' => $account['id']]);
                
                // Cập nhật số lượng đã bán của sản phẩm
                update('products', ['sold' => $product['sold'] + 1], 'id = :id', ['id' => $product_id]);
                
                // Trừ tiền người dùng
                $new_balance = $balance - $discounted_price;
                update('users', ['balance' => $new_balance], 'id = :id', ['id' => $user_id]);
                
                // Cập nhật session
                $_SESSION['balance'] = $new_balance;
                
                // Commit transaction
                $conn->commit();
                
                // Hiển thị thông tin tài khoản đã mua
                $account_data = json_decode($account['account_data'], true);
                $success_message = "Mua tài khoản thành công!";
                
            } catch (Exception $e) {
                // Rollback transaction nếu có lỗi
                $conn->rollBack();
                $error_message = "Có lỗi xảy ra: " . $e->getMessage();
            }
        }
    }
}

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.jpg');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo htmlspecialchars($product['name']); ?> - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/responsive.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Roboto', sans-serif;
        background-color: #f5f7fa;
    }

    .card-product {
        color: white;
        background-image: linear-gradient(to right, #12214E, #12214E, #013B7B);
    }

    .iq-sidebar {
        background: linear-gradient(180deg, #1a237e, #283593, #303f9f);
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        width: 250px;
    }
    
    .iq-sidebar-menu .side-menu li a {
        border-radius: 6px;
        transition: all 0.2s ease;
        margin: 2px 8px;
        padding: 8px 10px;
    }
    
    .iq-sidebar-menu .side-menu li a:hover,
    .iq-sidebar-menu .side-menu li a.active {
        background: rgba(255, 255, 255, 0.12);
        color: #fff;
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.12);
    }

    .change-mode .custom-switch.custom-switch-icon label.custom-control-label:after {
        top: 0;
        left: 0;
        width: 35px;
        height: 30px;
        border-radius: 5px 0 0 5px;
        background-color: #12214E;
        border-color: #12214E;
        z-index: 0;
    }
    
    .discount-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        padding: 6px 12px;
        background-color: #FF5722;
        color: white;
        border-radius: 50px;
        font-weight: bold;
        box-shadow: 0 2px 8px rgba(255, 87, 34, 0.25);
        z-index: 10;
        font-size: 0.85rem;
    }
    
    .product-detail {
        background: linear-gradient(135deg, #1a237e, #303f9f);
        padding: 20px;
        border-radius: 12px;
        color: white;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        position: relative;
        overflow: hidden;
    }
    
    .product-detail::before {
        content: "";
        position: absolute;
        top: 0;
        right: 0;
        width: 120px;
        height: 120px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50%;
        transform: translate(50%, -50%);
    }
    
    .account-info {
        background: rgba(255,255,255,0.12);
        padding: 15px;
        border-radius: 8px;
        margin-top: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-left: 3px solid #4CAF50;
    }
    
    .price-section .text-warning {
        font-size: 1.6rem;
        font-weight: bold;
        color: #FFD54F !important;
    }
    
    .card {
        border: none;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
    }
    
    .card-header {
        background-color: #fff;
        border-bottom: 1px solid rgba(0, 0, 0, 0.04);
        padding: 15px 20px;
    }
    
    .card-body {
        padding: 20px;
    }
    
    .btn {
        border-radius: 6px;
        padding: 8px 16px;
        font-weight: 500;
        transition: all 0.25s ease;
        font-size: 0.95rem;
    }
    
    .btn-success {
        background: #4CAF50;
        border-color: #4CAF50;
        box-shadow: 0 3px 8px rgba(76, 175, 80, 0.25);
    }
    
    .btn-success:hover {
        background: #43A047;
        transform: translateY(-2px);
        box-shadow: 0 5px 12px rgba(76, 175, 80, 0.35);
    }
    
    .btn-warning {
        background: #FF9800;
        border-color: #FF9800;
        box-shadow: 0 3px 8px rgba(255, 152, 0, 0.25);
    }
    
    .btn-warning:hover {
        background: #F57C00;
        transform: translateY(-2px);
        box-shadow: 0 5px 12px rgba(255, 152, 0, 0.35);
    }
    
    .btn-outline-primary {
        border-color: #3F51B5;
        color: #3F51B5;
    }
    
    .btn-outline-primary:hover {
        background-color: #3F51B5;
        color: #fff;
        box-shadow: 0 3px 8px rgba(63, 81, 181, 0.25);
    }
    
    .alert {
        border-radius: 8px;
        border: none;
        box-shadow: 0 3px 12px rgba(0, 0, 0, 0.04);
        padding: 12px 15px;
        margin-bottom: 15px;
    }
    
    .alert-success {
        background-color: #E8F5E9;
        color: #2E7D32;
        border-left: 3px solid #4CAF50;
    }
    
    .alert-warning {
        background-color: #FFF8E1;
        color: #F57F17;
        border-left: 3px solid #FFC107;
    }
    
    .alert-danger {
        background-color: #FFEBEE;
        color: #C62828;
        border-left: 3px solid #F44336;
    }
    
    .alert-info {
        background-color: #E3F2FD;
        color: #1565C0;
        border-left: 3px solid #2196F3;
    }
    
    hr {
        border-color: rgba(255, 255, 255, 0.08);
        margin: 15px 0;
    }
    
    .payment-summary {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.04);
    }
    
    .text-success {
        color: #4CAF50 !important;
    }
    
    .product-title {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 5px;
        line-height: 1.2;
    }
    
    .category-badge {
        display: inline-block;
        background: rgba(255, 255, 255, 0.15);
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.8rem;
        margin-bottom: 15px;
    }
    
    .product-stat {
        display: flex;
        align-items: center;
        background: rgba(255, 255, 255, 0.08);
        padding: 8px 12px;
        border-radius: 6px;
        margin-bottom: 8px;
        font-size: 0.95rem;
    }
    
    .product-stat i {
        margin-right: 8px;
        font-size: 1.1rem;
    }
    
    .side-menu-header {
        background: rgba(255, 255, 255, 0.1);
        padding: 6px 10px;
        border-radius: 6px;
        margin: 8px 0 5px;
        font-size: 0.75rem;
    }

    .input-group-text {
        padding: 0.375rem 0.75rem;
        font-size: 0.9rem;
    }
    
    .form-control {
        height: calc(1.5em + 0.75rem + 2px);
        padding: 0.375rem 0.75rem;
        font-size: 0.9rem;
    }
    
    .copy-btn {
        padding: 0.375rem 0.75rem;
    }
    
    .container-fluid {
        padding-left: 15px;
        padding-right: 15px;
    }
    
    .py-4 {
        padding-top: 1.25rem !important;
        padding-bottom: 1.25rem !important;
    }
    
    .mb-0 {
        margin-bottom: 0 !important;
    }
    
    .mb-1 {
        margin-bottom: 0.25rem !important;
    }
    
    .mt-2 {
        margin-top: 0.5rem !important;
    }
    
    .mt-3 {
        margin-top: 0.75rem !important;
    }
    
    .mt-4 {
        margin-top: 1rem !important;
    }
    
    .mr-1 {
        margin-right: 0.25rem !important;
    }
    
    .mr-2 {
        margin-right: 0.5rem !important;
    }
    
    .mr-3 {
        margin-right: 0.75rem !important;
    }
    
    @media (max-width: 767.98px) {
        .product-detail {
            margin-bottom: 15px;
        }
        
        .product-title {
            font-size: 1.5rem;
        }
        
        .iq-sidebar {
            width: 220px;
        }
    }
    </style>
</head>
<body class="color-light">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="iq-sidebar sidebar-default">
            <div class="iq-sidebar-logo d-flex align-items-center justify-content-between">
                <a href="<?php echo $base_url; ?>/home.php" class="header-logo">
                    <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="img-fluid rounded-normal light-logo" alt="logo" style="height: 45px;">
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="24" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>

            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <li class="px-3 pt-2 pb-1">
                            <div class="side-menu-header">
                                <span class="text-uppercase small font-weight-bold">Số Dư <span style="color: #FFD54F;"><?php echo formatMoney($balance); ?></span> - Giảm: <span style="color: #FF5252;"><?php echo $discount; ?>%</span>
                                </span>
                            </div>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php" class="svg-icon">
                                <i class="fas fa-home"></i>
                                <span class="ml-2">Bảng Điều Khiển</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/shop-account.php" class="svg-icon active">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="ml-2">Mua Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/orders.php" class="svg-icon">
                                <i class="fas fa-history"></i>
                                <span class="ml-2">Lịch Sử Mua Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/top-money.php" class="svg-icon">
                                <i class="fas fa-trophy"></i>
                                <span class="ml-2">Bảng Xếp Hạng</span>
                            </a>
                        </li>
                        <li class="px-3 pt-2 pb-1">
                            <div class="side-menu-header">
                                <span class="text-uppercase small font-weight-bold">Nạp Tiền</span>
                            </div>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/recharge.php" class="svg-icon">
                                <i class="fas fa-university"></i>
                                <span class="ml-2">Ngân Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/invoices.php" class="svg-icon">
                                <i class="fas fa-file-invoice"></i>
                                <span class="ml-2">Hoá Đơn</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/nap-the.php" class="svg-icon">
                                <i class="fas fa-credit-card"></i>
                                <span class="ml-2">Nạp Thẻ</span>
                            </a>
                        </li>
                        <li class="px-3 pt-2 pb-1">
                            <div class="side-menu-header">
                                <span class="text-uppercase small font-weight-bold">Tài Khoản</span>
                            </div>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/profile.php" class="svg-icon">
                                <i class="fas fa-user-edit"></i>
                                <span class="ml-2">Thông Tin Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php?logout=1" class="svg-icon">
                                <i class="fas fa-sign-out-alt"></i>
                                <span class="ml-2">Đăng Xuất</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid py-4">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <div class="header-title">
                                    <h4 class="card-title mb-0">Chi Tiết Sản Phẩm</h4>
                                </div>
                                <div>
                                    <a href="<?php echo $base_url; ?>/shop-account.php" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-arrow-left mr-1"></i> Quay lại
                                    </a>
                                </div>
                            </div>
                            <div class="card-body">
                                
                                <?php if(!empty($success_message)): ?>
                                <div class="alert alert-success" id="success-alert">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-check-circle mr-3" style="font-size: 1.25rem;"></i>
                                        <h5 class="mb-0"><?php echo $success_message; ?></h5>
                                    </div>
                                    
                                    <?php if(isset($account_data)): ?>
                                    <div class="account-info mt-3">
                                        <p class="font-weight-bold mb-2">Thông tin tài khoản:</p>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text bg-primary text-white">
                                                            <i class="fas fa-user"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($account_data['username']); ?>" readonly>
                                                    <div class="input-group-append">
                                                        <button type="button" class="btn btn-outline-primary copy-btn" data-clipboard-text="<?php echo htmlspecialchars($account_data['username']); ?>">
                                                            <i class="fas fa-copy"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="input-group mb-2">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text bg-primary text-white">
                                                            <i class="fas fa-key"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($account_data['password']); ?>" readonly>
                                                    <div class="input-group-append">
                                                        <button type="button" class="btn btn-outline-primary copy-btn" data-clipboard-text="<?php echo htmlspecialchars($account_data['password']); ?>">
                                                            <i class="fas fa-copy"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="alert alert-warning mb-0 mt-2">
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-exclamation-triangle mr-2" style="font-size: 1rem;"></i>
                                                <p class="mb-0">Lưu ý: Vui lòng lưu lại thông tin tài khoản ngay lập tức!</p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo $base_url; ?>/orders.php" class="btn btn-outline-success btn-sm mt-2">
                                        <i class="fas fa-list mr-1"></i> Xem lịch sử mua hàng
                                    </a>
                                </div>
                                <?php endif; ?>
                                
                                <?php if(!empty($error_message)): ?>
                                <div class="alert alert-danger">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-exclamation-circle mr-2" style="font-size: 1.25rem;"></i>
                                        <p class="mb-0"><?php echo $error_message; ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="product-detail">
                                            <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                                            <div class="category-badge">
                                                <i class="fas fa-tag mr-1"></i> <?php echo htmlspecialchars($product['category_name']); ?>
                                            </div>
                                            
                                            <?php if($discount > 0): ?>
                                            <div class="discount-badge">
                                                <i class="fas fa-bolt mr-1"></i> Giảm <?php echo $discount; ?>%
                                            </div>
                                            <?php endif; ?>
                                            
                                            <div class="my-3">
                                                <h6 class="mb-2"><i class="fas fa-info-circle mr-2"></i>Mô tả:</h6>
                                                <div class="p-2 bg-white bg-opacity-10 rounded">
                                                    <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                                                </div>
                                            </div>
                                            
                                            <div class="row mt-3">
                                                <div class="col-md-6">
                                                    <div class="product-stat">
                                                        <i class="fas fa-box-open"></i>
                                                        <span>Kho: <strong><?php echo $product['available_accounts']; ?></strong></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="product-stat">
                                                        <i class="fas fa-shopping-cart"></i>
                                                        <span>Đã bán: <strong><?php echo $product['sold']; ?></strong></span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <hr>
                                            
                                            <div class="price-section mt-3">
                                                <?php if($discount > 0): ?>
                                                <div class="d-flex align-items-center">
                                                    <p class="h6 mr-2 mb-0">Giá gốc: <span class="text-muted"><del><?php echo formatMoney($product['price']); ?></del></span></p>
                                                    <span class="badge badge-danger">-<?php echo $discount; ?>%</span>
                                                </div>
                                                <p class="h4 mt-2 mb-0">Giá ưu đãi: <span class="text-warning"><?php echo formatMoney($discounted_price); ?></span></p>
                                                <?php else: ?>
                                                <p class="h4 mb-0">Giá: <span class="text-warning"><?php echo formatMoney($product['price']); ?></span></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="card shadow-sm">
                                            <div class="card-body">
                                                <h5 class="card-title mb-3"><i class="fas fa-credit-card mr-2"></i>Thông tin thanh toán</h5>
                                                
                                                <div class="alert alert-info d-flex align-items-center mb-3">
                                                    <i class="fas fa-wallet mr-2" style="font-size: 1.2rem;"></i>
                                                    <div>
                                                        <span>Số dư hiện tại:</span>
                                                        <h5 class="mb-0 mt-1"><?php echo formatMoney($balance); ?></h5>
                                                    </div>
                                                </div>
                                                
                                                <div class="payment-summary">
                                                    <h6 class="font-weight-bold mb-2">Tóm tắt đơn hàng:</h6>
                                                    <div class="d-flex justify-content-between mb-1">
                                                        <span>Giá sản phẩm:</span>
                                                        <span class="font-weight-bold"><?php echo formatMoney($product['price']); ?></span>
                                                    </div>
                                                    <?php if($discount > 0): ?>
                                                    <div class="d-flex justify-content-between mb-1">
                                                        <span>Giảm giá (<?php echo $discount; ?>%):</span>
                                                        <span class="text-danger">-<?php echo formatMoney($product['price'] - $discounted_price); ?></span>
                                                    </div>
                                                    <?php endif; ?>
                                                    <hr class="my-2">
                                                    <div class="d-flex justify-content-between font-weight-bold mt-2">
                                                        <span>Tổng cộng:</span>
                                                        <span class="text-success h5 mb-0"><?php echo formatMoney($discounted_price); ?></span>
                                                    </div>
                                                </div>
                                                
                                                <?php if($balance < $discounted_price): ?>
                                                <div class="alert alert-warning mt-3 mb-2">
                                                    <div class="d-flex align-items-center">
                                                        <i class="fas fa-exclamation-triangle mr-2" style="font-size: 1rem;"></i>
                                                        <div>
                                                            <p class="mb-1">Số dư không đủ. Vui lòng nạp thêm:</p>
                                                            <h6 class="text-danger mb-0"><?php echo formatMoney($discounted_price - $balance); ?></h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <a href="<?php echo $base_url; ?>/recharge.php" class="btn btn-warning btn-block">
                                                    <i class="fas fa-wallet mr-1"></i> Nạp Tiền
                                                </a>
                                                <?php else: ?>
                                                
                                                <?php if($product['available_accounts'] > 0 && empty($success_message)): ?>
                                                <form method="POST" action="" class="mt-3">
                                                    <button type="submit" name="buy_product" class="btn btn-success btn-block">
                                                        <i class="fas fa-shopping-cart mr-1"></i> Mua Ngay
                                                    </button>
                                                </form>
                                                <?php elseif(empty($success_message)): ?>
                                                <div class="alert alert-danger mt-3 mb-0">
                                                    <div class="d-flex align-items-center">
                                                        <i class="fas fa-times-circle mr-2" style="font-size: 1rem;"></i>
                                                        <p class="mb-0">Sản phẩm đã hết hàng.</p>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo $base_url; ?>/public/js/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });
            
            // Auto-hide success message after 15 seconds
            $("#success-alert").fadeTo(15000, 500).slideUp(500, function(){
                $("#success-alert").slideUp(500);
            });
            
            // Initialize clipboard for copy buttons
            var clipboard = new ClipboardJS('.copy-btn');
            
            clipboard.on('success', function(e) {
                $(e.trigger).html('<i class="fas fa-check"></i>');
                setTimeout(function() {
                    $(e.trigger).html('<i class="fas fa-copy"></i>');
                }, 1500);
                e.clearSelection();
            });
        });
    </script>
</body>
</html> 