<?php
session_start();
require_once 'config.php';

// Nếu đã đăng nhập, chuyển hướng đến trang chủ
if (isLoggedIn()) {
    redirect($base_url . '/home.php');
}

// Xử lý đăng ký
if (isset($_POST['register'])) {
    $username = validateInput($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $email = isset($_POST['email']) ? validateInput($_POST['email']) : '';
    
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $error = "Vui lòng điền đầy đủ thông tin";
    } elseif ($password != $confirm_password) {
        $error = "Mật khẩu xác nhận không khớp";
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
        $error = "Tên đăng nhập phải từ 3-20 ký tự, chỉ gồm chữ cái, số và dấu gạch dưới";
    } elseif (strlen($password) < 6) {
        $error = "Mật khẩu phải có ít nhất 6 ký tự";
    } else {
        // Kiểm tra xem tên đăng nhập đã tồn tại chưa
        $check_username = find("SELECT id FROM users WHERE username = :username LIMIT 1", ['username' => $username]);
        
        if ($check_username) {
            $error = "Tên đăng nhập đã tồn tại, vui lòng chọn tên khác";
        } else {
            // Kiểm tra email nếu có
            if (!empty($email)) {
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = "Định dạng email không hợp lệ";
                } else {
                    $check_email = find("SELECT id FROM users WHERE email = :email LIMIT 1", ['email' => $email]);
                    if ($check_email) {
                        $error = "Email đã được sử dụng, vui lòng chọn email khác";
                    }
                }
            }
            
            if (!isset($error)) {
                // Mã hóa mật khẩu
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Thêm người dùng mới vào database
                $data = [
                    'username' => $username,
                    'password' => $hashed_password,
                    'email' => $email,
                    'balance' => 0,
                    'discount_percent' => 0
                ];
                
                $user_id = insert('users', $data);
                
                if ($user_id) {
                    // Đăng nhập tự động sau khi đăng ký
                    $_SESSION['logged_in'] = true;
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['username'] = $username;
                    $_SESSION['balance'] = 0;
                    $_SESSION['discount'] = 0;
                    
                    redirect($base_url . '/home.php');
                } else {
                    $error = "Đăng ký không thành công, vui lòng thử lại sau";
                }
            }
        }
    }
}

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.jpg');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Đăng Ký - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #0a1436 0%, #0d2870 50%, #01234d 100%);
        color: white;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .auth-card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 40px;
        max-width: 500px;
        width: 100%;
        margin: 30px auto;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        animation: fadeIn 0.5s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .form-control {
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: white;
        border-radius: 8px;
        padding: 12px 15px;
        transition: all 0.3s ease;
        margin-bottom: 15px;
    }
    .form-control:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.3);
        box-shadow: 0 0 0 3px rgba(255, 153, 0, 0.2);
        color: white;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        font-size: 14px;
        letter-spacing: 0.5px;
    }
    .form-text {
        color: rgba(255, 255, 255, 0.6) !important;
        font-size: 12px;
        margin-top: 5px;
    }
    .btn-primary {
        background: linear-gradient(135deg, #FF9900, #FF6600);
        border: none;
        border-radius: 8px;
        padding: 12px;
        font-weight: 600;
        letter-spacing: 0.5px;
        box-shadow: 0 4px 15px rgba(255, 153, 0, 0.3);
        transition: all 0.3s ease;
    }
    .btn-primary:hover {
        background: linear-gradient(135deg, #FF8800, #FF5500);
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(255, 153, 0, 0.4);
    }
    .btn-primary:active {
        transform: translateY(0);
    }
    .logo {
        max-width: 150px;
        margin-bottom: 20px;
    }
    .alert {
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 25px;
        font-weight: 500;
        border-left: 4px solid #dc3545;
    }
    .alert-danger {
        background-color: rgba(220, 53, 69, 0.1);
    }
    h2 {
        font-weight: 600;
        margin-bottom: 25px;
        font-size: 28px;
    }
    a {
        color: #FF9900;
        transition: color 0.3s;
        text-decoration: none;
    }
    a:hover {
        color: #FFB340;
        text-decoration: none;
    }
    .text-center a {
        font-weight: 600;
    }
    .input-group {
        position: relative;
        margin-bottom: 15px;
    }
    .input-icon {
        position: absolute;
        top: 14px;
        left: 15px;
        color: rgba(255, 255, 255, 0.5);
    }
    .form-control.with-icon {
        padding-left: 40px;
    }
    .form-footer {
        text-align: center;
        margin-top: 30px;
        color: rgba(255, 255, 255, 0.7);
    }
    .wave {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100px;
        background: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1440 320" xmlns="http://www.w3.org/2000/svg"><path fill="%23FF9900" fill-opacity="0.2" d="M0,192L48,170.7C96,149,192,107,288,112C384,117,480,171,576,176C672,181,768,139,864,117.3C960,96,1056,96,1152,122.7C1248,149,1344,203,1392,229.3L1440,256L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
        background-size: cover;
        background-repeat: no-repeat;
        z-index: -1;
    }
    @media (max-width: 576px) {
        .auth-card {
            margin: 15px;
            padding: 25px;
        }
        h2 {
            font-size: 24px;
        }
    }
    </style>
</head>
<body>
    <div class="wave"></div>
    <div class="container">
        <div class="auth-card">
            <div class="text-center mb-4">
                <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="logo" alt="Logo">
                <h2>Đăng Ký Tài Khoản</h2>
            </div>
            
            <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Tên đăng nhập</label>
                    <div class="input-group">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" class="form-control with-icon" id="username" name="username" placeholder="Nhập tên đăng nhập" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                    </div>
                    <small class="form-text text-muted">Từ 3-20 ký tự, chỉ gồm chữ cái, số và dấu gạch dưới</small>
                </div>
                <div class="form-group">
                    <label for="email">Email (không bắt buộc)</label>
                    <div class="input-group">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" class="form-control with-icon" id="email" name="email" placeholder="Nhập email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">Mật khẩu</label>
                    <div class="input-group">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" class="form-control with-icon" id="password" name="password" placeholder="Nhập mật khẩu">
                    </div>
                    <small class="form-text text-muted">Mật khẩu phải có ít nhất 6 ký tự</small>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Xác nhận mật khẩu</label>
                    <div class="input-group">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" class="form-control with-icon" id="confirm_password" name="confirm_password" placeholder="Nhập lại mật khẩu">
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" name="register" class="btn btn-primary btn-block">Đăng Ký</button>
                </div>
                <div class="form-footer">
                    <p>Đã có tài khoản? <a href="<?php echo $base_url; ?>/login.php">Đăng nhập ngay</a></p>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Add Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</body>
</html> 