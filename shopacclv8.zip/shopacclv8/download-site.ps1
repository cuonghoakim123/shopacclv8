# PowerShell script to download essential website files
$baseUrl = "https://shopacclv8.top"
$outputDir = "."

# Create necessary directories
$directories = @(
    "assets/storage/images",
    "public/datum/assets/css",
    "resources/css",
    "public/sweetalert2",
    "public/cute-alert",
    "public/js"
)

foreach ($dir in $directories) {
    if (-not (Test-Path "$outputDir/$dir")) {
        New-Item -ItemType Directory -Path "$outputDir/$dir" -Force
    }
}

# Download CSS files
$cssFiles = @(
    "/public/datum/assets/css/backend-plugin.min.css",
    "/resources/css/responsive.css",
    "/resources/css/backend.css",
    "/resources/css/customize.css",
    "/public/sweetalert2/default.css",
    "/public/cute-alert/style.css"
)

foreach ($file in $cssFiles) {
    $url = $baseUrl + $file
    $outputPath = "$outputDir" + $file
    Write-Host "Downloading $url to $outputPath"
    try {
        Invoke-WebRequest -Uri $url -OutFile $outputPath
    } catch {
        Write-Host "Failed to download $url : $_"
    }
}

# Download JavaScript files
$jsFiles = @(
    "/resources/js/jquery.js",
    "/public/sweetalert2/sweetalert2.js",
    "/public/cute-alert/cute-alert.js",
    "/public/js/jquery-3.6.0.js"
)

foreach ($file in $jsFiles) {
    $url = $baseUrl + $file
    $outputPath = "$outputDir" + $file
    Write-Host "Downloading $url to $outputPath"
    try {
        Invoke-WebRequest -Uri $url -OutFile $outputPath
    } catch {
        Write-Host "Failed to download $url : $_"
    }
}

# Download image files
$imageFiles = @(
    "/assets/storage/images/logo_dark_XGI.png",
    "/assets/storage/images/favicon_UPQ.png",
    "/assets/storage/images/image_6DN.png"
)

foreach ($file in $imageFiles) {
    $url = $baseUrl + $file
    $outputPath = "$outputDir" + $file
    Write-Host "Downloading $url to $outputPath"
    try {
        Invoke-WebRequest -Uri $url -OutFile $outputPath
    } catch {
        Write-Host "Failed to download $url : $_"
    }
}

Write-Host "Download completed!" 