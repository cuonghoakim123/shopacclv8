<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Require configuration file
require_once 'config.php';

// Check if user is logged in
if (!function_exists('isLoggedIn') || !isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Get current user ID and info
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Get user's orders
$orders = findAll("SELECT o.*, 
                    (SELECT p.name FROM products p JOIN order_items oi ON p.id = oi.product_id WHERE oi.order_id = o.id LIMIT 1) AS product_name,
                    (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS total_accounts
                  FROM orders o
                  WHERE o.user_id = :user_id
                  ORDER BY o.created_at DESC", 
                  ['user_id' => $user_id]);

// Get site settings
$site_name = getSetting('site_name', 'Shop Accl V8');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.png');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Lịch Sử Mua Hàng - <?php echo htmlspecialchars($site_name); ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url . '/' . $site_favicon; ?>" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap 4.6 & Font Awesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" 
          integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" 
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Variables & Global Settings */
        :root {
            --primary-color: #013B7B;
            --secondary-color: #12214E;
            --accent-color: #FF9900;
            --light-bg: #f4f6fc;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            --font-family: 'Poppins', sans-serif;
        }
        * {
            box-sizing: border-box;
        }
        body {
            margin: 0;
            font-family: var(--font-family);
            background: var(--light-bg);
            color: #333;
            overflow-x: hidden;
            line-height: 1.6;
        }
        a {
            text-decoration: none;
            transition: all 0.3s ease;
        }
        a:hover {
            color: var(--accent-color);
        }

        /* Layout */
        .wrapper {
            display: flex;
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        .wrapper.sidebar-main .iq-sidebar {
            transform: translateX(-100%);
        }

        /* Sidebar */
        .iq-sidebar {
            width: 260px;
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            padding: 20px;
            position: fixed;
            height: 100vh;
            box-shadow: var(--shadow);
            z-index: 100;
            transition: transform 0.3s ease;
        }
        .iq-sidebar-logo {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
        }
        .iq-sidebar-logo img {
            max-width: 80%;
            border-radius: 15px;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }
        .iq-sidebar-logo img:hover {
            transform: scale(1.1);
            box-shadow: 0 5px 15px rgba(255, 153, 0, 0.5);
        }
        .iq-sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .iq-sidebar-menu li {
            margin-bottom: 12px;
            position: relative;
        }
        .iq-sidebar-menu li a, 
        .iq-sidebar-menu li span {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            border-radius: 10px;
            font-weight: 500;
            color: #fff;
            transition: all 0.3s ease;
        }
        .iq-sidebar-menu li a:hover,
        .iq-sidebar-menu li a.active {
            background: var(--accent-color);
            transform: translateX(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .iq-sidebar-menu li a i {
            margin-right: 10px;
            transition: transform 0.3s ease;
        }
        .iq-sidebar-menu li a:hover i {
            transform: scale(1.2);
        }
        .wrapper-menu {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            color: #fff;
            font-size: 24px;
        }

        /* Main Content */
        .content-page {
            flex: 1;
            margin-left: 260px;
            padding: 50px 40px;
            background: linear-gradient(135deg, #ffffff 0%, #e9eff5 100%);
            position: relative;
            overflow: hidden;
        }
        .content-page::before {
            content: "";
            position: absolute;
            top: -50px;
            left: -50px;
            width: 120%;
            height: 300px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            z-index: -1;
            border-bottom-left-radius: 60% 40%;
            border-bottom-right-radius: 60% 40%;
            opacity: 0.4;
            transform: rotate(-5deg);
        }

        /* Card */
        .card {
            background: #fff;
            border-radius: 20px;
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: #fff;
            padding: 20px;
            border-bottom: none;
        }
        .card-title {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        .card-body {
            padding: 30px;
        }

        /* Table */
        .table {
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .table thead th {
            background: var(--secondary-color);
            color: #fff;
            border: none;
            padding: 15px;
            text-transform: uppercase;
            font-size: 0.9rem;
        }
        .table tbody tr {
            transition: background 0.3s ease;
        }
        .table tbody tr:hover {
            background: rgba(255, 153, 0, 0.1);
        }
        .table td {
            vertical-align: middle;
            padding: 15px;
        }
        .badge {
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
        }
        .badge-success {
            background: #28a745;
        }
        .badge-danger {
            background: #dc3545;
        }
        .btn-info {
            background: var(--accent-color);
            border: none;
            border-radius: 50px;
            padding: 8px 20px;
            transition: all 0.3s ease;
        }
        .btn-info:hover {
            background: var(--primary-color);
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* No Orders Alert */
        .alert-info {
            background: linear-gradient(135deg, #e9ecef, #dee2e6);
            border: none;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: var(--shadow);
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 50px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: var(--accent-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 153, 0, 0.4);
        }

        /* Responsive Adjustments */
        @media (max-width: 991px) {
            .iq-sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px;
            }
            .content-page {
                margin-left: 0;
                padding: 30px 20px;
            }
            .table-responsive {
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <aside class="iq-sidebar">
            <div class="iq-sidebar-logo">
                <a href="<?php echo $base_url; ?>/home.php">
                    <img src="<?php echo $base_url . '/' . $site_logo; ?>" class="img-fluid rounded-normal" alt="logo">
                </a>
                <i class="fas fa-times wrapper-menu"></i>
            </div>
            <ul class="iq-sidebar-menu">
                <li class="px-3 pt-3 pb-2">
                    <span class="text-uppercase small font-weight-bold">
                        Số Dư: <span style="color: yellow;"><?php echo number_format($balance, 0, ',', '.'); ?> VNĐ</span> - 
                        Giảm: <span style="color: red;"><?php echo $discount; ?>%</span>
                    </span>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/home.php"><i class="fas fa-home"></i> <span class="ml-2">Bảng Điều Khiển</span></a>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/shop-account.php"><i class="fas fa-shopping-cart"></i> <span class="ml-2">Mua Tài Khoản</span></a>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/orders.php" class="active"><i class="fas fa-history"></i> <span class="ml-2">Lịch Sử Mua Hàng</span></a>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/top-money.php"><i class="fas fa-trophy"></i> <span class="ml-2">Bảng Xếp Hạng</span></a>
                </li>
                <li class="px-3 pt-3 pb-2">
                    <span class="text-uppercase small font-weight-bold">Nạp Tiền</span>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/recharge.php"><i class="fas fa-university"></i> <span class="ml-2">Ngân Hàng</span></a>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/invoices.php"><i class="fas fa-file-invoice"></i> <span class="ml-2">Hoá Đơn</span></a>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/nap-the.php"><i class="fas fa-credit-card"></i> <span class="ml-2">Nạp Thẻ</span></a>
                </li>
                <li class="px-3 pt-3 pb-2">
                    <span class="text-uppercase small font-weight-bold">Tài Khoản</span>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/profile.php"><i class="fas fa-user-edit"></i> <span class="ml-2">Thông Tin Tài Khoản</span></a>
                </li>
                <li>
                    <a href="<?php echo $base_url; ?>/home.php?logout=1"><i class="fas fa-sign-out-alt"></i> <span class="ml-2">Đăng Xuất</span></a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Lịch Sử Mua Hàng</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if (count($orders) > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Mã giao dịch</th>
                                                    <th>Sản phẩm</th>
                                                    <th>Số lượng</th>
                                                    <th>Tổng thanh toán</th>
                                                    <th>Thời gian</th>
                                                    <th>Trạng thái</th>
                                                    <th>Hành động</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($orders as $order): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($order['transaction_code']); ?></td>
                                                        <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                                                        <td><?php echo $order['total_accounts']; ?></td>
                                                        <td><?php echo number_format($order['total_amount'], 0, ',', '.'); ?> VNĐ</td>
                                                        <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                                                        <td>
                                                            <?php if ($order['status'] == 1): ?>
                                                                <span class="badge badge-success">Thành công</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-danger">Đã hủy</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <a href="<?php echo $base_url; ?>/order-detail.php?id=<?php echo $order['id']; ?>" 
                                                               class="btn btn-sm btn-info">
                                                                <i class="fas fa-eye"></i> Chi tiết
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle"></i> Bạn chưa có đơn hàng nào.
                                    </div>
                                    <a href="<?php echo $base_url; ?>/shop-account.php" class="btn btn-primary">
                                        <i class="fas fa-shopping-cart"></i> Mua tài khoản ngay
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });

            // Fade-in effect for table rows
            $('tbody tr').each(function(i) {
                $(this).delay(i * 200).fadeIn(500);
            });
        });
    </script>
</body>
</html>