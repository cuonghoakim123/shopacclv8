<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Get current user ID and info
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Get deposit history
$deposits = findAll("SELECT * FROM deposits WHERE user_id = :user_id ORDER BY created_at DESC", 
                 ['user_id' => $user_id]);

// Get site settings
$site_name = getSetting('site_name', 'Shop Accl V8');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.jpg');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');

// Bank information
$banks = [
    [
        'name' => 'BIDV - Ngân hàng TMCP Đầu tư và Phát triển Việt Nam',
        'account_name' => 'NGUYEN DAI KIM CUONG',
        'account_number' => '117****766',
        'logo' => 'assets/images/bank-logos/bidv.png'
    ],
    [
        'name' => 'Vietcombank - Ngân hàng TMCP Ngoại thương Việt Nam',
        'account_name' => 'NGUYEN DAI KIM CUONG',
        'account_number' => '1023456789',
        'logo' => 'assets/images/bank-logos/vcb.png'
    ]
];

// Page title
$page_title = "Nạp Tiền";
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url . '/' . $site_favicon; ?>" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" 
          integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" 
          crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Variables & Global Settings */
        :root {
            --primary-color: #013B7B;
            --secondary-color: #12214E;
            --accent-color: #FF9900;
            --light-bg: #f4f6fc;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            --font-family: 'Poppins', sans-serif;
        }
        * {
            box-sizing: border-box;
        }
        body {
            margin: 0;
            font-family: var(--font-family);
            background: var(--light-bg);
            color: #333;
            overflow-x: hidden;
            line-height: 1.6;
        }
        a {
            text-decoration: none;
            transition: all 0.3s ease;
        }
        a:hover {
            color: var(--accent-color);
        }

        /* Layout */
        .wrapper {
            display: flex;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* Sidebar */
        .iq-sidebar {
            width: 260px;
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            padding: 20px;
            position: fixed;
            height: 100vh;
            box-shadow: var(--shadow);
            z-index: 100;
            transition: transform 0.3s ease;
        }
        .iq-sidebar-logo {
            text-align: center;
            margin-bottom: 40px;
        }
        .iq-sidebar-logo img {
            max-width: 80%;
            border-radius: 15px;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }
        .iq-sidebar-logo img:hover {
            transform: scale(1.1);
            box-shadow: 0 5px 15px rgba(255, 153, 0, 0.5);
        }
        .iq-sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .iq-sidebar-menu li {
            margin-bottom: 12px;
            position: relative;
        }
        .iq-sidebar-menu li a, 
        .iq-sidebar-menu li span {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            border-radius: 10px;
            font-weight: 500;
            color: #fff;
            transition: all 0.3s ease;
        }
        .iq-sidebar-menu li a:hover,
        .iq-sidebar-menu li a.active {
            background: var(--accent-color);
            transform: translateX(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .iq-sidebar-menu li a i {
            margin-right: 10px;
            transition: transform 0.3s ease;
        }
        .iq-sidebar-menu li a:hover i {
            transform: scale(1.2);
        }

        /* Main Content */
        .content-page {
            flex: 1;
            margin-left: 260px;
            padding: 50px 40px;
            background: linear-gradient(135deg, #ffffff 0%, #e9eff5 100%);
            position: relative;
            overflow: hidden;
        }
        .content-page::before {
            content: "";
            position: absolute;
            top: -50px;
            left: -50px;
            width: 120%;
            height: 300px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            z-index: -1;
            border-bottom-left-radius: 60% 40%;
            border-bottom-right-radius: 60% 40%;
            opacity: 0.4;
            transform: rotate(-5deg);
        }

        .qr-card {
            border-radius: 20px;
            overflow: hidden;
            border: none;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            background: linear-gradient(to bottom right, #1e4b9c, #4589d6, #95d45e);
            max-width: 400px;
            margin: 0 auto;
        }
        .qr-card .card-body {
            background: white;
            padding: 20px;
            border-bottom-left-radius: 20px;
            border-bottom-right-radius: 20px;
        }
        .qr-logo {
            padding: 15px;
            text-align: center;
        }
        .qr-logo img {
            height: 80px;
        }
        .qr-container {
            background: white;
            padding: 15px;
            border-radius: 10px;
            display: inline-block;
            position: relative;
        }
        .qr-container .qr-overlay {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 40px;
            height: 40px;
            background-color: #e30613;
            color: white;
            font-weight: bold;
            font-size: 24px;
            line-height: 40px;
            text-align: center;
            border-radius: 50%;
        }
        .bank-info {
            color: #003c71;
            font-weight: 500;
        }
        .bank-logos {
            margin-top: 10px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        .bank-logos img {
            height: 30px;
            margin: 0 5px;
        }

        /* Status colors */
        .status-pending {
            color: #f39c12;
        }
        .status-completed {
            color: #2ecc71;
        }
        .status-cancelled {
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <aside class="iq-sidebar">
            <div class="iq-sidebar-logo">
                <a href="home.php">
                    <img src="<?php echo $site_logo; ?>" alt="Shop Accl V8 Logo">
                </a>
            </div>
            <ul class="iq-sidebar-menu">
                <li class="px-3 pb-2">
                    <span>Số Dư: <strong style="color: var(--accent-color);"><?php echo number_format($balance, 0, ',', '.'); ?> VNĐ</strong> - Giảm: <strong style="color: red;"><?php echo $discount; ?>%</strong></span>
                </li>
                <li>
                    <a href="home.php"><i class="fas fa-home"></i> <span class="ml-2">Bảng Điều Khiển</span></a>
                </li>
                <li>
                    <a href="shop-account.php"><i class="fas fa-shopping-cart"></i> <span class="ml-2">Mua Tài Khoản</span></a>
                </li>
                <li>
                    <a href="orders.php"><i class="fas fa-history"></i> <span class="ml-2">Lịch Sử Mua Hàng</span></a>
                </li>
                <li>
                    <a href="top-money.php"><i class="fas fa-trophy"></i> <span class="ml-2">Bảng Xếp Hạng</span></a>
                </li>
                <li class="px-3 pt-3 pb-2">
                    <span>Nạp Tiền</span>
                </li>
                <li>
                    <a href="recharge.php" class="active"><i class="fas fa-university"></i> <span class="ml-2">Ngân Hàng</span></a>
                </li>
                <li>
                    <a href="invoices.php"><i class="fas fa-file-invoice"></i> <span class="ml-2">Hoá Đơn</span></a>
                </li>
                <li>
                    <a href="nap-the.php"><i class="fas fa-credit-card"></i> <span class="ml-2">Nạp Thẻ</span></a>
                </li>
                <li class="px-3 pt-3 pb-2">
                    <span>Tài Khoản</span>
                </li>
                <li>
                    <a href="profile.php"><i class="fas fa-user-edit"></i> <span class="ml-2">Thông Tin Tài Khoản</span></a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span class="ml-2">Đăng Xuất</span></a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-header bg-primary text-white">
                                <h4 class="mb-0">Nạp Tiền Vào Tài Khoản</h4>
                            </div>
                            <div class="card-body">
                                <div class="alert alert-info">
                                    <p><strong>Lưu ý:</strong> Vui lòng chuyển khoản với nội dung là <strong>"NAP <?php echo $username; ?>"</strong> vào một trong các tài khoản ngân hàng sau.</p>
                                    <p>Hệ thống sẽ tự động cập nhật số dư sau khi nhận được giao dịch (thông thường trong vòng 1-5 phút).</p>
                                </div>

                                <!-- VietQR style card for BIDV -->
                                <div class="qr-card mb-4">
                                    <div class="qr-logo">
                                        <h3 class="text-white">VietQR</h3>
                                    </div>
                                    <div class="text-center p-3">
                                        <div class="qr-container">
                                            <!-- Inline SVG QR Code -->
                                            <svg xmlns="http://www.w3.org/2000/svg" width="250" height="250" viewBox="0 0 21 21">
                                                <path d="M0,0 h21v21H0z" fill="#FFFFFF"/>
                                                <path d="M0,0h7v7H0z M1,1h5v5H1z M2,2h3v3H2z M14,0h7v7h-7z M15,1h5v5h-5z M16,2h3v3h-16z M0,14h7v7H0z M1,15h5v5H1z M2,16h3v3H2z M7,3h1v1H7z M9,2h1v2H9z M13,2h1v1h-1z M11,3h1v1h-1z M8,4h1v1H8z M10,4h1v1h-1z M12,4h1v1h-1z M14,4h1v1h-1z M7,5h3v1H7z M11,5h2v1h-2z M7,6h1v1H7z M9,6h3v1H9z M13,6h1v1h-1z M9,7h1v1H9z M11,7h1v1h-1z M13,7h1v1h-1z M7,8h2v1H7z M10,8h1v1h-1z M12,8h1v1h-1z M7,9h1v1H7z M9,9h2v1H9z M12,9h1v1h-1z M14,9h1v1h-1z M7,10h1v1H7z M9,10h1v1H9z M11,10h1v1h-1z M14,10h1v1h-1z M7,11h1v1H7z M9,11h1v1H9z M11,11h2v1h-2z M14,11h1v1h-1z M7,12h1v1H7z M9,12h1v1H9z M11,12h1v1h-1z M13,12h2v1h-2z M0,7h1v1H0z M6,7h1v1H6z M3,9h3v1H3z M2,11h3v1H2z M8,14h3v1H8z M12,14h1v1h-1z M14,14h1v1h-1z M8,15h1v1H8z M10,15h1v1h-1z M12,15h1v1h-1z M14,15h1v1h-1z M8,16h1v1H8z M10,16h1v1h-1z M12,16h1v1h-1z M14,16h1v1h-1z M8,17h1v1H8z M10,17h1v1h-1z M12,17h1v1h-1z M14,17h1v1h-1z M8,18h1v1H8z M10,18h1v1h-10z M12,18h1v1h-1z M14,18h1v1h-1z M8,19h1v1H8z M10,19h1v1h-1z M12,19h1v1h-1z M14,19h1v1h-1z M14,19h1v1h-1z M16,7h5v1h-5z M15,8h1v1h-1z M14,9h1v1h-1z M15,10h1v1h-1z M17,11h1v1h-1z M19,12h2v1h-2z M16,14h3v1h-3z M16,17h2v1h-2z M16,19h2v1h-2z" fill="#000000"/>
                                            </svg>
                                            <div class="qr-overlay">V</div>
                                        </div>
                                    </div>
                                    <div class="card-body text-center">
                                        <p class="mb-1"><strong>Tên chủ TK:</strong> NGUYEN DAI KIM CUONG</p>
                                        <p class="mb-1"><strong>Số TK:</strong> 117****766</p>
                                        <p class="mb-3"><strong>Ngân hàng TMCP Đầu tư và Phát triển Việt Nam</strong></p>
                                        
                                        <div class="bank-logos">
                                            <span class="border rounded px-2 py-1 mr-2">NAPAS</span>
                                            <span class="border rounded px-2 py-1">BIDV</span>
                                        </div>
                                        <p class="small text-muted mt-2">Tạo bởi VietQR.net</p>
                                    </div>
                                </div>

                                <div class="mt-4">
                                    <h5>Lịch sử nạp tiền</h5>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Mã giao dịch</th>
                                                    <th>Số tiền</th>
                                                    <th>Phương thức</th>
                                                    <th>Thời gian</th>
                                                    <th>Trạng thái</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (empty($deposits)): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center">Chưa có lịch sử giao dịch</td>
                                                </tr>
                                                <?php else: ?>
                                                    <?php foreach ($deposits as $deposit): ?>
                                                    <tr>
                                                        <td><?php echo $deposit['transaction_code']; ?></td>
                                                        <td><?php echo number_format($deposit['amount'], 0, ',', '.'); ?> VNĐ</td>
                                                        <td><?php echo $deposit['payment_method']; ?></td>
                                                        <td><?php echo date('d/m/Y H:i', strtotime($deposit['created_at'])); ?></td>
                                                        <td>
                                                            <?php 
                                                            switch ($deposit['status']) {
                                                                case 0:
                                                                    echo '<span class="badge badge-warning">Đang xử lý</span>';
                                                                    break;
                                                                case 1:
                                                                    echo '<span class="badge badge-success">Thành công</span>';
                                                                    break;
                                                                case 2:
                                                                    echo '<span class="badge badge-danger">Đã hủy</span>';
                                                                    break;
                                                                default:
                                                                    echo '<span class="badge badge-secondary">Không xác định</span>';
                                                            }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
    <script>
        $(document).ready(function() {
            // Copy account number functionality if needed
        });
    </script>
</body>
</html> 