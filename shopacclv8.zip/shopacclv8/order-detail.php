<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect($base_url . '/login.php');
}

// Lấy thông tin người dùng từ database
$user_id = getCurrentUserId();
$user = find("SELECT * FROM users WHERE id = :id LIMIT 1", ['id' => $user_id]);

if (!$user) {
    session_destroy();
    redirect($base_url . '/login.php');
}

$username = $user['username'];
$balance = $user['balance'];
$discount = $user['discount_percent'];

// Kiểm tra ID đơn hàng
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect($base_url . '/orders.php');
}

$order_id = intval($_GET['id']);

// Lấy thông tin đơn hàng
$order = find("SELECT * FROM orders WHERE id = :id AND user_id = :user_id LIMIT 1", [
    'id' => $order_id,
    'user_id' => $user_id
]);

if (!$order) {
    redirect($base_url . '/orders.php');
}

// Lấy chi tiết đơn hàng
$order_items = findAll("SELECT oi.*, p.name as product_name, a.account_data 
                        FROM order_items oi
                        JOIN products p ON oi.product_id = p.id
                        JOIN accounts a ON oi.account_id = a.id
                        WHERE oi.order_id = :order_id", 
                        ['order_id' => $order_id]);

// Lấy tên trang web từ cài đặt
$site_name = getSetting('site_name', 'SHOP CUNG CẤP ACC FF LV5, LV8 GIÁ RẺ NHẤT THỊ TRƯỜNG');
$site_logo = getSetting('site_logo', 'assets/storage/images/5.png');
$site_favicon = getSetting('site_favicon', 'assets/storage/images/favicon_UPQ.png');
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Chi Tiết Đơn Hàng - <?php echo $site_name; ?></title>
    <link rel="shortcut icon" href="<?php echo $base_url; ?>/<?php echo $site_favicon; ?>" />
    <link rel="stylesheet" href="<?php echo $base_url; ?>/public/datum/assets/css/backend-plugin.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/responsive.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/backend.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/resources/css/customize.css">
    <script src="<?php echo $base_url; ?>/resources/js/jquery.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    body {
        font-family: 'Roboto', sans-serif;    
    }

    .iq-sidebar {
        background: linear-gradient(#12214E, #12214E, #013B7B);
    }

    .change-mode .custom-switch.custom-switch-icon label.custom-control-label:after {
        top: 0;
        left: 0;
        width: 35px;
        height: 30px;
        border-radius: 5px 0 0 5px;
        background-color: #12214E;
        border-color: #12214E;
        z-index: 0;
    }
    
    .account-info {
        background-color: #f8f9fa;
        border-radius: 5px;
        padding: 15px;
        margin-bottom: 15px;
    }
    
    .account-info h6 {
        border-bottom: 1px solid #dee2e6;
        padding-bottom: 10px;
        margin-bottom: 10px;
    }
    
    .account-field {
        margin-bottom: 8px;
    }
    
    .account-field strong {
        display: inline-block;
        width: 120px;
    }
    </style>
</head>
<body class="color-light">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="iq-sidebar sidebar-default">
            <div class="iq-sidebar-logo d-flex align-items-end justify-content-between">
                <a href="<?php echo $base_url; ?>/home.php" class="header-logo">
                    <img src="<?php echo $base_url; ?>/<?php echo $site_logo; ?>" class="img-fluid rounded-normal light-logo" alt="logo">
                </a>
                <div class="side-menu-bt-sidebar-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="text-light wrapper-menu" width="30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="side-menu">
                        <li class="px-3 pt-3 pb-2">
                            <span class="text-uppercase small font-weight-bold">Số Dư <span style="color: yellow;"><?php echo formatMoney($balance); ?></span> - Giảm: <span style="color: red;"><?php echo $discount; ?>%</span>
                            </span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php" class="svg-icon">
                                <i class="fas fa-home"></i>
                                <span class="ml-2">Bảng Điều Khiển</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/shop-account.php" class="svg-icon">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="ml-2">Mua Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/orders.php" class="svg-icon active">
                                <i class="fas fa-history"></i>
                                <span class="ml-2">Lịch Sử Mua Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/top-money.php" class="svg-icon">
                                <i class="fas fa-trophy"></i>
                                <span class="ml-2">Bảng Xếp Hạng</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Nạp Tiền</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/recharge.php" class="svg-icon">
                                <i class="fas fa-university"></i>
                                <span class="ml-2">Ngân Hàng</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/invoices.php" class="svg-icon">
                                <i class="fas fa-file-invoice"></i>
                                <span class="ml-2">Hoá Đơn</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/nap-the.php" class="svg-icon">
                                <i class="fas fa-credit-card"></i>
                                <span class="ml-2">Nạp Thẻ</span>
                            </a>
                        </li>
                        <li class="px-3 pt-3 pb-2 ">
                            <span class="text-uppercase small font-weight-bold">Tài Khoản</span>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/profile.php" class="svg-icon">
                                <i class="fas fa-user-edit"></i>
                                <span class="ml-2">Thông Tin Tài Khoản</span>
                            </a>
                        </li>
                        <li class="sidebar-layout">
                            <a href="<?php echo $base_url; ?>/home.php?logout=1" class="svg-icon">
                                <i class="fas fa-sign-out-alt"></i>
                                <span class="ml-2">Đăng Xuất</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Chi Tiết Đơn Hàng #<?php echo $order['transaction_code']; ?></h4>
                                </div>
                                <div class="card-header-toolbar">
                                    <a href="<?php echo $base_url; ?>/orders.php" class="btn btn-primary">
                                        <i class="fas fa-arrow-left"></i> Quay lại
                                    </a>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <h5>Thông tin đơn hàng</h5>
                                        <p><strong>Mã giao dịch:</strong> <?php echo $order['transaction_code']; ?></p>
                                        <p><strong>Ngày mua:</strong> <?php echo date('d/m/Y H:i:s', strtotime($order['created_at'])); ?></p>
                                        <p><strong>Tổng thanh toán:</strong> <?php echo formatMoney($order['total_amount']); ?></p>
                                        <p>
                                            <strong>Trạng thái:</strong> 
                                            <?php if($order['status'] == 1): ?>
                                            <span class="badge badge-success">Thành công</span>
                                            <?php else: ?>
                                            <span class="badge badge-danger">Đã hủy</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                
                                <h5>Danh sách tài khoản</h5>
                                <?php if (count($order_items) > 0): ?>
                                    <?php foreach($order_items as $index => $item): ?>
                                        <?php 
                                        $account_data = json_decode($item['account_data'], true);
                                        ?>
                                        <div class="account-info">
                                            <h6>Tài khoản #<?php echo $index+1; ?> - <?php echo htmlspecialchars($item['product_name']); ?></h6>
                                            <?php foreach($account_data as $key => $value): ?>
                                            <div class="account-field">
                                                <strong><?php echo ucfirst(htmlspecialchars($key)); ?>:</strong>
                                                <span><?php echo htmlspecialchars($value); ?></span>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle"></i> Không tìm thấy thông tin tài khoản cho đơn hàng này.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo $base_url; ?>/public/js/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Toggle sidebar
            $('.wrapper-menu').click(function() {
                $('.wrapper').toggleClass('sidebar-main');
            });
        });
    </script>
</body>
</html> 