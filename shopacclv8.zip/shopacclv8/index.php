<?php
// Include home.php directly
include_once 'home.php';
?> 